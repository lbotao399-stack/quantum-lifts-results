#!/bin/sh
set -eu
cd "$(dirname "$0")"
if command -v sha256sum >/dev/null 2>&1; then
    sha256sum -c SHA256SUMS >/dev/null
else
    shasum -a 256 -c SHA256SUMS >/dev/null
fi
scratch="$(mktemp -d "${TMPDIR:-/tmp}/f4-eight-full.XXXXXX")"
printf 'Full replay workspace: %s\n' "$scratch"
cp -R f4-j36-eight-cubic f4-j36-nested1-seal fixtures "$scratch/"
cd "$scratch/f4-j36-eight-cubic"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 F4_ALL_PLANS=1
py="${PYTHON:-python3}"
cp bank-B-reduced.json expected-bank.json
"$py" export_typed.py
node typed.js B >typed-B.correct.json
"$py" build_bank.py B
"$py" reduce_native.py B
cmp bank-B-reduced.json expected-bank.json
"$py" export_contraction.py
"$py" chevalley_swap.py
if [ "$#" -gt 0 ]; then
    for prime in 1009 1013; do
        mv "outgoing-$prime.json" "expected-outgoing-$prime.json"
        F4_CAL_PRIME="$prime" "$py" -u outgoing.py "$1" >"outgoing-$prime-replay.log"
        cmp "outgoing-$prime.json" "expected-outgoing-$prime.json"
    done
fi
rm native-B-*-1009.log native-B-*-1013.log
# Positive and negative dotted sets each have six occupied chords. Each listed
# sector represents two occupation-swapped graphs; DOT_SWAP.md proves equality.
for prime in 1009 1013; do
    P="$prime" "$py" -u native.py B left 0 1 2 6 7 8 12 13 14 >"native-B-left-replayed-$prime.log"
    "$py" collect.py "$prime" swap
    F4_CAL_PRIME="$prime" "$py" augmented_minor.py
done
# Disjoint terms are literally identical for both marks. Recompute all
# inequivalent overlapping graphs for the other mark at the first prime.
P=1009 "$py" -u native.py B right 12 13 14 18 19 20 21 22 23 >native-B-right-replayed-1009.log
"$py" collect.py 1009 swap right
"$py" - <<'PY'
import json
from pathlib import Path
l,r=(json.loads(Path(f'comparison-B-{side}-1009.json').read_text()) for side in ('left','right'))
assert [l[k] for k in ('raw','L','section','residual')]==[r[k] for k in ('raw','L','section','residual')]==[361,663,44,619]
PY
