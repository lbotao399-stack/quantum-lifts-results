from itertools import combinations_with_replacement,product
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
from math import lcm,gcd
from sympy import Matrix
import numpy as np,json,hashlib
D=Path(__file__).resolve().parent
p=D.parent/'fixtures/color-basis-native.json'
blob=p.read_bytes()
assert hashlib.sha256(blob).hexdigest()=='030c2bf73e82a33b59721dea76bd3478d24ee7e01fc6bf805a6c97d0ba29e71c'
J=json.loads(blob)
n=26;R=np.zeros((52,n,n),dtype=np.int64)
for i,a in enumerate(J['representation26']):
 for j,k,x in a:R[i,j,k]=int(x)
assert all(not np.any(A-np.diag(np.diag(A)))for A in R[:4])
wt=np.diagonal(R[:4],axis1=1,axis2=2).T
slots=[t for t in combinations_with_replacement(range(n),3)if not np.any(wt[list(t)].sum(axis=0))]
N=len(slots);print('cubic coordinates',N,flush=True)
eq={}
def cols(i):return np.flatnonzero(R[:,i,:].sum(axis=0))
for u in range(52):
 ans={}
 for q,t in enumerate(slots):
  for a,r in enumerate(t):
   for y in np.flatnonzero(R[u,r,:]):
    s=t[:a]+(int(y),)+t[a+1:]
    # For a chosen ordered output s, sum contributions from each designated slot.
    # Distinct permutations of t produce multiple identical equations, so instead
    # recompute each sorted resulting s once directly below.
    ans[tuple(sorted(s))]=0
 for s in ans:
  z=[0]*N;Dslots={t:q for q,t in enumerate(slots)}
  for i,y in enumerate(s):
   for r in np.flatnonzero(R[u,:,y]):
    t=tuple(sorted(s[:i]+(int(r),)+s[i+1:]))
    j=Dslots.get(t)
    if j is not None:z[j]+=int(R[u,r,y])
  if any(z):eq[tuple(z)]=True
K=Matrix(list(eq)).nullspace();assert len(K)==1
v=list(map(F,K[0]));den=lcm(*(a.denominator for a in v))
v=[int(den*a)for a in v];g=gcd(*v);v=[a//g for a in v]
C=np.zeros((26,)*3,dtype=np.int64)
from itertools import permutations
for t,a in zip(slots,v):
 for p in set(permutations(t)):C[p]=a
for A in R:
 Y=np.einsum('abc,ai->ibc',C,A)
 assert not np.any(Y+Y.transpose(1,0,2)+Y.transpose(1,2,0))
h=np.zeros((26,26),dtype=np.int64)
for i,j,z in J['representationInvariantForm']:h[i,j]=int(z)
hi=Matrix(h.tolist()).inv()
MM=[hi*Matrix(X.tolist())for X in C]
Q=Matrix(26,26,lambda i,j:(MM[i]*MM[j]).trace())
ix=next((i,j)for i in range(26)for j in range(26)if h[i,j])
k=Q[ix]/int(h[ix]);assert Q==k*Matrix(h.tolist()) and k
T=[[*map(int,t),int(C[t])]for t in zip(*np.nonzero(C))]
print('verified 52 native Ward identities, support',len(T),'norm',k,flush=True)
(D/'cubic.json').write_text(json.dumps({'cubic':T,'k':str(k),'variables':N,'equations':len(eq)})+'\n')
