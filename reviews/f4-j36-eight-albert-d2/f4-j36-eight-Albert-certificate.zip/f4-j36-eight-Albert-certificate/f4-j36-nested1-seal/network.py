"""Exact numerator contraction on a six-chord, six-Albert terminal network."""
from pathlib import Path
from itertools import product
from collections import defaultdict
from functools import cache
from math import prod,lcm,comb
from fractions import Fraction as F
import numpy as np,json,time,sys,os
D=Path(__file__).resolve().parent
J=json.loads((D.parent/'fixtures/color-basis-native.json').read_text())
C0=json.loads((D/'cubic.json').read_text())
BANK=json.loads((D/os.getenv('F4_GRAPH_BANK','nested0-calibration-bank.json' if os.getenv('F4_CALIBRATION','0')=='1' else 'graph_bank.json')).read_text())
P=int(os.getenv('P','0'))
def gram(N,data):
 den=lcm(*(F(v).denominator for *_,v in data))
 m=np.zeros((N,N),dtype=np.int64)
 for i,j,v in data:m[i,j]=int(den*F(v))
 return den,m
_,h=gram(26,J['representationInvariantForm']);hI=3*h.copy();hI[:2,:2]=[[2,1],[1,2]]
_,B=gram(52,J['metric']);dg,Bi=gram(52,J['inverseMetric'])
assert np.array_equal(h@hI,3*np.eye(26,dtype=np.int64))
assert np.array_equal(B@Bi,dg*np.eye(52,dtype=np.int64))
rep=np.zeros((52,26,26),dtype=np.int64);adj=np.zeros((52,52,52),dtype=np.int64)
for p,rr in enumerate(J['representation26']):
 for x,y,z in rr:rep[p,x,y]=int(z)
for x,y,t in J['bracketPairs']:
 for k,z in t:adj[x,k,y]=int(z);adj[y,k,x]=-int(z)
T={26:rep.transpose(0,2,1)@h,52:adj.transpose(0,2,1)@B}
assert all(not np.any(t+t.transpose(0,2,1))for t in T.values())
DUAL={d:(Bi@r.reshape(52,-1)).reshape(52,d,d).transpose(0,2,1)for d,r in [(26,rep),(52,adj)]}
mi={26:hI,52:Bi}
C=np.zeros((26,)*3,dtype=np.int64)
for x,y,z,v in C0['cubic']:C[x,y,z]=v
weights=[-4*2392*7113106,2*2299*1850212]
POLS=[((19,29,31,45,46,47),(42,18,17,12,11,9)),((19,20,29,45,46,47),(42,39,18,12,11,9))]
red=lambda x:x%P if P else x
def act(X,H,i):
 Y=np.moveaxis(X,i,-1);sh=Y.shape
 assert sh[-1]*int(np.max(np.abs(Y)))*int(np.max(np.abs(H)))<2**63
 return np.moveaxis(red(Y.reshape(-1,sh[-1])@H).reshape(*sh[:-1],H.shape[-1]),-1,i)
def alt(a,b):return (-1)**sum((b&((1<<i)-1)).bit_count()for i in range(6)if a>>i&1)
sign={(a,b):alt(a,b)for a in range(64)for b in range(64)if not a&b}
COMP={(a,b):comb(6,a)**2*comb(6-a,b)**2 for a in range(7)for b in range(7-a)}
def plan(E,ds,ch):
 bd=[sum(1<<i for i,(a,b) in enumerate(E)if ((m>>a)^(m>>b))&1)for m in range(1024)]
 @cache
 def weights(m):return prod(ds[i]for i in range(15)if m>>i&1)
 parts=[]
 for m in range(1024):
  pp=[];a=(m-1)&m
  while a:
   b=m^a
   if a<b and bd[a]&bd[b]:pp.append((a,b,weights(bd[a]|bd[b])))
   a=(a-1)&m
  parts.append(pp)
 best=(10**80,None,None)
 for bits in product(range(2),repeat=6):
  own=[0]*10
  for e,s in zip(ch,bits):own[E[e][s]]+=1
  amt=[0]*1024
  for m in range(1,1024):
   t=m&-m;amt[m]=amt[m^t]+own[t.bit_length()-1]
  dp=[10**60]*1024;ptr=[None]*1024
  for m in range(1,1024):
   if bd[m].bit_count()>5:continue # sparse storage; never materialize dense contracted tensors
   if m.bit_count()==1:dp[m]=0;continue
   for a,b,c in parts[m]:
    j=dp[a]+dp[b]+c*COMP[amt[a],amt[b]]
    if j<dp[m]:dp[m]=j;ptr[m]=(a,b)
  if dp[-1]<best[0] and dp[-1]<10**59:
   def parse(m):
    if m.bit_count()==1:return m.bit_length()-1
    a,b=ptr[m];return (parse(a),parse(b))
   best=(dp[-1],bits,parse(1023))
 if best[1] is None:raise Exception('no bounded plan')
 return best
@cache
def net(gstring):
 g=json.loads(gstring);E=g['E'];ds=g['d'];ch=g['ch'];pl=plan(E,ds,ch);return E,ds,ch,pl
def run(g,branch,fixed=False):
 E,ds,ch,(_,bits,pl)=net(json.dumps(g,sort_keys=True));uu,vv=POLS[branch]
 owner={e:E[e][s] for e,s in zip(ch,bits)}
 allEdges={}
 for i in ch:
  d=ds[i];A=DUAL[d]
  for u,v in product(range(6),repeat=2):
   allEdges[i,u,v]=red(mi[d]@A[uu[u]]@A[vv[v]])
 def leaf(x):
  inc=tuple(i for i,(s,t) in enumerate(E)if x in (s,t))
  if x<g.get('cubics',6):X=C.copy()
  else:
   if any(ds[i]==26 for i in inc):
    d=26
    cov=(next(i for i in inc if ds[i]==26 and E[i][1]==x),next(i for i in inc if ds[i]==26 and E[i][0]==x),next(i for i in inc if ds[i]==52))
   else:
    d=52
    cov=(next(i for i in inc if i!=14 and E[i][1]==x),next(i for i in inc if i!=14 and E[i][0]==x),14)
   X=np.moveaxis(T[d],0,-1).transpose([cov.index(i)for i in inc]).copy()
  for a,i in enumerate(inc):
   if i not in ch and E[i][0]==x:X=act(X,mi[ds[i]],a)
  take=tuple(i for i in inc if owner.get(i)==x);R={(0,0):X}
  for i in take:
   j=ch.index(i);a=inc.index(i);U={}
   for u,v in ([ (j,j) ] if fixed else product(range(6),repeat=2)):
    u1,v1=1<<u,1<<v
    H=allEdges[i,u,v];H=H if E[i][0]==x else H.T
    for (b,c),Y in R.items():
     if b&u1 or c&v1:continue
     k=(b|u1,c|v1)
     z=act(Y,H,a)*sign[b,u1]*sign[c,v1]
     U[k]=red(z+(U[k]if k in U else 0))
   R=U
  out={}
  for p,Q in R.items():
   i=np.nonzero(Q)
   if len(i[0]):out[p]=dict(zip(zip(*(map(int,r)for r in i)),map(int,Q[i])))
  return inc,out
 def split(R,side,mid):
  out={}
  for a,G in R.items():
   j=defaultdict(list)
   for ix,n in G.items():j[tuple(ix[i]for i in mid)].append((tuple(ix[i]for i in side),n))
   out[a]=j
  return out
 def con(t):
  if isinstance(t,int):return leaf(t)
  (a,X),(b,Y)=map(con,t)
  g=tuple(i for i in a if i in b);l=tuple(i for i in a if i not in g);r=tuple(i for i in b if i not in g)
  L=split(X,[a.index(i)for i in l],[a.index(i)for i in g]);del X
  R=split(Y,[b.index(i)for i in r],[b.index(i)for i in g]);del Y
  out=defaultdict(lambda:defaultdict(int))
  for (u,v),G in L.items():
   for (x,y),H in R.items():
    if u&x or v&y:continue
    D0=out[u|x,v|y];s=1 if fixed else sign[u,x]*sign[v,y]
    J=G if len(G)<=len(H)else H
    for q in J:
     if q in G and q in H:
      for i,a0 in G[q]:
       a0*=s
       for j,b0 in H[q]:D0[i+j]+=a0*b0
  o={k:{j:red(a)for j,a in H.items()if red(a)}for k,H in out.items()}
  return l+r,{k:j for k,j in o.items()if j}
 I,V=con(pl)
 assert not I
 z=V.get((63,63),{}).get((),0)
 d=3**ds.count(26)*dg**(ds.count(52)+12)
 return z*pow(d,-1,P)%P if P else F(z,d)
if __name__=='__main__':
 mode=int(sys.argv[1]);emit=[]; known={}
 if mode==1 and not os.getenv('F4_GRAPH_BANK') and not P and os.getenv('F4_CALIBRATION','0')!='1' and (D/'native-qq-0.log').exists():
  for line in (D/'native-qq-0.log').read_text().splitlines():
   if not line.startswith('graph '):continue
   _,_,j,_,_,_,a,b,*_=line.split()
   g=BANK[0][int(j)];known[json.dumps([g['E'],g['d'],g['ch']])]=list(map(F,(a,b)))

 for i,g in enumerate(BANK[mode]):
  start=time.monotonic()
  if len(sys.argv)>2 and i not in set(map(int,sys.argv[2:])):continue
  ky=json.dumps([g['E'],g['d'],g['ch']]);v=known.get(ky)
  if v is None:v=[run(g,b)for b in (0,1)]
  L=red(sum(x*y for x,y in zip(v,weights)))
  print('graph',mode,i,'weight',g['w'],'poles',*[str(x)for x in v],'lambda',L,'seconds',round(time.monotonic()-start,2),flush=True)
  emit.append([i,g['w'],*[str(x)for x in v],str(L)])
 if len(emit)==len(BANK[mode]):
  s=red(sum(w*F(x)for i,w,a,b,x in emit))
  k=F(C0['k']);n=BANK[mode][0].get('cubics',6);fac=k**3 if n==6 else 6*k*k
  assert all(x.get('cubics',6)==n for x in BANK[mode])
  result=(s*fac.denominator*pow(fac.numerator*2,-1,P))%P if P else s/(2*fac)
  print('final',mode,'sum',s,'normalized',result,flush=True)
