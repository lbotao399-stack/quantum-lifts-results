"""Batch independently varied six-Albert W1 tapes on the certified 703 chart."""
import nested2_outgoing as b
from nested2_outgoing import p,chart,R,Lo,Hi,M,act,cent,sg,alt_mid,COM,D
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from time import monotonic
import json,os,sys,gzip,numpy as np

def ep(side,XX,BR,layout):
 X=[a.T if side else a for a in XX];C0=Lo if side else Hi
 a0,a1,a2=layout
 S=np.zeros((26,)*4)
 for i,j in COM:
  k,l=tuple(u for u in range(4)if u not in (i,j));A=BR[i,j];A=A.T if side else A
  B=act(A,C0,a0)
  U=act(X[l],act(X[k],B,a1),a2);V=act(X[k],act(X[l],B,a1),a2)
  S+=sg((i,j,k,l))*(cent(U)-cent(V))
 return cent(S)
LAY=[]
if os.getenv('F4_OP_EXCHANGE')=='adjoint':
 import network as N
 W=N.rep.reshape(52,-1)
 M=(((W.T@N.Bi)%p)@W)%p
 M=b.cent((M*pow(6*N.dg,-1,p)%p).reshape((26,)*4).transpose(0,2,1,3).reshape(676,676))

def evaluate(i):
 seed=chart['points'][i]
 coeff=np.random.Generator(np.random.PCG64(144336+seed)).integers(-3,4,size=(4,52))
 Xs=(coeff@R.reshape(52,-1)).reshape(4,26,26).astype(float)
 marks={(i,j):Xs[i]@Xs[j]-Xs[j]@Xs[i] for i,j in COM}
 E=({},{});V=({},{});ans=[]
 for tag,L,LM,Ry,RM,EX in LAY:
  for side,k,m,XE in ((1,L,LM,None),(0,Ry,RM,EX)):
   if (k,m,XE) in V[side]:continue
   if k not in E[side]:E[side][k]=ep(side,Xs,marks,k)
   X=Xs.transpose(0,2,1)if side else Xs
   Z=alt_mid(E[side][k],X,m)
   if not side:
    assert len(XE)==2 and tuple(sorted(XE))==XE
    Z=np.moveaxis(Z,XE,(0,1));Z=cent(M@Z.reshape(676,676)).reshape((26,)*4)
    Z=np.moveaxis(Z,(0,1),XE)
   V[side][k,m,XE]=Z.ravel()
  ans.append(int(V[1][L,LM,None]@V[0][Ry,RM,EX])%p)
 return ans

def er(A,y):
 Z=np.column_stack((A,y))%p;r=len(A);det=1
 for j in range(r):
  v=np.flatnonzero(Z[j:,j]);assert len(v);k=j+int(v[0]);w=int(Z[k,j]);det=det*w%p
  if j!=k:Z[[j,k],j:]=Z[[k,j],j:];det=-det
  Z[j,j:]=Z[j,j:]*pow(w,-1,p)%p
  f=Z[j+1:,j]; Z[j+1:,j:]=(Z[j+1:,j:]-f[:,None]*Z[j,j:])%p
 C=Z[:,r:].copy()
 for j in reversed(range(r)):
  C[j]=(C[j]-Z[j,j+1:r]@C[j+1:])%p
 assert np.array_equal(A@C%p,y%p)
 return C,det%p
def setup():
 A=np.frombuffer(gzip.decompress((D/f'selected-{p}.u16.gz').read_bytes()),dtype='<u2').reshape(703,703).astype(np.int64)
 f=lambda y:F(y).numerator*pow(F(y).denominator,-1,p)%p
 C=json.loads((D/'trace_C4_ordered.json').read_text())
 rows=np.array([[f(y)for y in z]for z in C['rows']],dtype=np.int64)
 q=[tuple(r)for r in chart['rows']].index(('nested',0))
 zz=np.array([f(x)for x in ('-104166480711910256640000','-17361080118651709440000','-109953507418127493120000','0')])
 s=rows@zz%p
 s[q]=f('-598031033628600/7')
 # Simultaneously solve interpolant, four trace covectors, nested0 covector.
 e=np.zeros((703,),dtype=np.int64);e[q]=1
 dual,det=er(A,np.column_stack((s,rows,e)))
 assert det=={1009:1005,1013:734}[p]
 return A,s,dual
if __name__=='__main__':
 tag=sys.argv[1];n=int(sys.argv[2]);start=monotonic()
 specs=json.loads((D/f'{tag}-layouts.json').read_text())
 LAY=[(t[0],*map(tuple,t[1:5]),tuple(t[5]) if len(t)==6 else (0,1))for t in specs]
 out=D/f'{tag}-outgoing-{p}.json';V=[]
 if out.exists():
  d=json.loads(out.read_text());assert d['specs']==specs;V=d['points']
 A,s,dual=setup()
 cal=np.array(json.loads((D/'nested2-outgoing-1009.json').read_text()))
 if p==1009 and os.getenv('F4_OP_EXCHANGE')!='adjoint':
  assert int((cal@dual[:,0])%p)==F('598031033628600/7').numerator*pow(7,-1,p)%p
  assert list(cal@dual[:,1:]%p)==[0,0,0,0,p-1]
  for i in (0,1,49):
   save=LAY;LAY=[('check', (0,1,2),(0,1,2),(0,1,2),(1,2,3),(0,1))]
   assert evaluate(i)==[int(cal[i])]
   LAY=save
 with ProcessPoolExecutor(max_workers=n) as ex:
  for i,x in zip(range(len(V),703),ex.map(evaluate,range(len(V),703),chunksize=1)):
   V.append(x)
   if (i+1)%10==0 or i==702:
    tmp=out.with_suffix('.tmp');tmp.write_text(json.dumps({'specs':specs,'points':V})+'\n');tmp.replace(out)
    print('committed',i+1,'secs',round(monotonic()-start,2),flush=True)
 mat=np.array(V,dtype=np.int64)
 witness=mat.T@dual%p
 print('interpolation, C4, nested0',witness.tolist(),flush=True)
 coords,det=er(A.T,mat);assert det=={1009:1005,1013:734}[p]
 assert np.array_equal(coords.T@s%p,witness[:,0])
 (D/f'{tag}-coordinates-{p}.json').write_text(json.dumps({'specs':specs,'interpolated':[[int(c)for c in u]for u in witness],'coordinates':coords.T.tolist(),'det':det})+'\n')
