"""Born rational outgoing vector of nested2 on every pinned calibration point."""
from fractions import Fraction as F
from itertools import combinations,permutations
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import os,sys,numpy as np,json
import network as N
D=Path(__file__).resolve().parent
p=int(os.getenv('F4_CAL_PRIME','1009'))
assert p in (1009,1013)
chart=json.loads((D/'selected-1009.json').read_text())
R=N.rep
C=N.C%p
hI=(N.hI*pow(3,-1,p))%p
k=F(N.C0['k']); proj=k.denominator*pow(k.numerator,-1,p)%p
def mul(A,B):
 v=A@B
 return v
Clo=C.reshape(26,-1)
Chi=(hI@C@hI%p).reshape(26,-1)
Cmid=(hI@C%p).reshape(26,-1)
def corner(T):
 # mod before second dot: 26*(p-1)^2 < 2^53 throughout.
 return (proj*((T.T@hI%p)@T%p)%p).reshape((26,)*4)
Lo=corner(Clo);Hi=corner(Chi).transpose(0,2,1,3);M=corner(Cmid).transpose(0,2,1,3).reshape(676,676).astype(float)
def cent(T):
 return ((T+p//2)%p-p//2).astype(float)
Lo,Hi=map(cent,(Lo,Hi));M=cent(M)
sg=lambda q:(-1)**sum(x>y for i,x in enumerate(q)for y in q[i+1:])
def act(A,F,axis):
 X=np.ascontiguousarray(np.moveaxis(F,axis,0)).reshape(26,-1)
 # All arrays integral; at the dangerous magnitude force a centered lift
 # of the input and recompute. 26 factors and ||X||∞ measured exactly.
 if np.max(np.abs(A))*np.max(np.abs(X))*26>1<<50:
  X=cent(X)
 assert np.max(np.abs(A))*np.max(np.abs(X))*26<=1<<50
 Y=A@X
 return np.moveaxis(Y.reshape((26,)*4),0,axis)
PER=list(permutations(range(3)))
COM=list(combinations(range(4),2))
def alt_mid(U,X,axes):
 v=np.zeros((26,)*4)
 for per in PER:
  v+=sg(per)*act(X[per[2]],act(X[per[1]],act(X[per[0]],U,axes[0]),axes[1]),axes[2])
 assert np.max(np.abs(v))<=6*(1<<50)
 return cent(v)
def prepare(side,XX,BR,rightbar):
 X=[a.T if side else a for a in XX];C0=Lo if side else Hi
 S=np.zeros((26,)*4)
 for i,j in COM:
  k,l=tuple(u for u in range(4)if u not in (i,j));A=BR[i,j];A=A.T if side else A
  B=act(A,C0,0)
  U=act(X[l],act(X[k],B,1),2);V=act(X[k],act(X[l],B,1),2)
  S+=sg((i,j,k,l))*(cent(U)-cent(V))
 assert np.max(np.abs(S))<=6*(1<<51)
 S=cent(S)
 return alt_mid(S,X,(0,1,2) if side else rightbar)
def evaluate(rowpos,rightbar=(1,2,3)):
 seed=chart['points'][rowpos]
 coeff=np.random.Generator(np.random.PCG64(144336+seed)).integers(-3,4,size=(4,52))
 Xs=(coeff@R.reshape(52,-1)).reshape(4,26,26).astype(float)
 marks={(i,j):Xs[i]@Xs[j]-Xs[j]@Xs[i] for i,j in COM}
 L=prepare(True,Xs,marks,rightbar).ravel()
 H=prepare(False,Xs,marks,rightbar).reshape(676,676)
 H=cent(M@H).ravel()
 return int(L@H)%p
if __name__=='__main__':
 import time
 start=time.monotonic()
 if len(sys.argv)>1 and sys.argv[1]=='check':
  import gzip
  q=[tuple(r)for r in chart['rows']].index(('nested',0))
  mat=np.frombuffer(gzip.decompress((D/f'selected-{p}.u16.gz').read_bytes()),dtype='<u2').reshape(703,703)
  for i in (0,1,49):
   a=evaluate(i,(0,1,2))
   b=evaluate(i)
   assert a==int(mat[q,i]),(i,a,int(mat[q,i]))
   print('control',p,i,'nested0',a,'nested2',b,'seconds',time.monotonic()-start,flush=True)
 else:
  dest=D/f'nested2-outgoing-{p}.json'
  if dest.exists():old=json.loads(dest.read_text())
  else:old=[]
  n=int(sys.argv[1]) if len(sys.argv)>1 else 1
  with ProcessPoolExecutor(max_workers=n) as ex:
   for i,x in zip(range(len(old),703),ex.map(evaluate,range(len(old),703),chunksize=1)):
    old.append(x)
    if (i+1)%10==0 or i==702:
     tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(old)+'\n');tmp.replace(dest)
     print(i+1,'seconds',round(time.monotonic()-start,2),flush=True)
