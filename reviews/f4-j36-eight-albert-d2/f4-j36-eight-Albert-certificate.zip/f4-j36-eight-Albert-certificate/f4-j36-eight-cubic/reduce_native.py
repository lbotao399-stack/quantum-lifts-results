"""Signed graph-isomorphism quotient, preserving colors and separate dot occupations."""
from pathlib import Path
import sys,json
from collections import Counter,defaultdict
from build_bank import parity
D=Path(__file__).resolve().parent

def keyed(G):
 n=max(max(e)for e in G['E'])+1
 E=G['E'];A=[{}for _ in range(n)];ep=[]
 for i,((a,b),d)in enumerate(zip(E,G['d'])):
  c=(d,int(i in G['cp']),int(i in G['cm']))
  if b in A[a] or a==b:return None # do not silently conflate parallel edges
  A[a][b]=(c,i);A[b][a]=(c,i);ep.append(c)
 def inv(A):
  typ=[tuple(sorted(c for c,_ in F.values()))for F in A]
  return [(typ[i],tuple(sorted((c,typ[j])for j,(c,_)in F.items()))) for i,F in enumerate(A)]
 v=inv(A);return A,v,tuple(sorted(v)),tuple(sorted(ep))

def orientation(g,h,s,EG,EH):
 def vertex(g,i):
  E=g['E'];d=g['d'];inc=sorted(j for j,(a,b)in enumerate(E)if i in (a,b))
  A=[j for j in inc if d[j]==52]
  F=[j for j in inc if d[j]==26]
  if i<g['cubics']:assert len(F)==3;return None
  if F:
   assert len(F)==2 and len(A)==1
   return [next(j for j in F if E[j][1]==i),next(j for j in F if E[j][0]==i),A[0]]
  assert len(A)==3
  hit=len(E)-1
  assert hit in A
  return [next(j for j in A if j!=hit and E[j][1]==i),next(j for j in A if j!=hit and E[j][0]==i),hit]
 M=[EH[s[a]][s[b]][1]for a,b in g['E']]
 v=parity([h['cp'].index(M[i])for i in g['cp']])*parity([h['cm'].index(M[i])for i in g['cm']])
 # A reversed singly occupied invariant propagator picks up one minus
 # from the skew representation. A reversed doubly occupied edge has
 # two minus signs, and order difference is a terminal Q0 bracket.
 for i,j in enumerate(M):
  if (i in g['cp'])!=(i in g['cm']):
   if [s[x]for x in g['E'][i]]==h['E'][j][::-1]:v=-v

 for a,b in s.items():
  X=vertex(g,a);Y=vertex(h,b)
  if X:v*=parity([Y.index(M[i])for i in X])
 return v

def iso(g,h,G,H):
 AG,VG,_,_=G;AH,VH,_,_=H
 pool=defaultdict(list)
 for j,v in enumerate(VH):pool[v].append(j)
 order=sorted(range(len(AG)),key=lambda i:len(pool[VG[i]]))
 f={};used=set();ans=set()
 def go():
  if len(ans)==2:return
  if len(f)==len(AG):ans.add(orientation(g,h,f,AG,AH));return
  i=min((k for k in order if k not in f),key=lambda k:(-sum(j in f for j in AG[k]),len(pool[VG[k]])))
  for v in pool[VG[i]]:
   if v in used:continue
   if any(AG[i].get(k,(None,))[0]!=AH[v].get(w,(None,))[0]for k,w in f.items()):continue
   f[i]=v;used.add(v);go();used.remove(v);del f[i]
 go();return ans
def reduce(L):
 B=defaultdict(list);fixed=[];odd=0
 for g in L:
  G=keyed(g)
  if not G:fixed.append(g);continue
  q=B[G[2:]]
  if iso(g,g,G,G)=={-1,1}:odd+=1;continue
  for h,H in q:
   r=iso(g,h,G,H)
   if r:
    assert len(r)==1
    s=r.pop();h['w']+=s*g['w'];h['orig'].append([g['tag'],g['w'],s]);break
  else:q.append((g,G))
 return [g for l in B.values()for g,_ in l if g['w']]+fixed,odd

if __name__=='__main__':
 tag=sys.argv[1];F=json.loads((D/f'bank-{tag}.json').read_text())
 for name,r in F.items():
  B=r['banks'];r['banks'],odd=reduce(B)
  print(name,'unreduced',len(B),'odd automorphisms',odd,'reduced',len(r['banks']))
 (D/f'bank-{tag}-reduced.json').write_text(json.dumps(F,separators=(',',':'))+'\n')
