"""Exact involution of literal F4 color, exchanging both pole pairs."""
from native import B,adj,POLS
import numpy as np
N=52
op=list(range(4))+[int(np.flatnonzero(B[i])[0])for i in range(4,N)]
assert [op[i]for i in op]==list(range(N))
piv={}
def add(bits,t):
 while bits:
  j=bits.bit_length()-1
  if j not in piv:piv[j]=(bits,t);return
  b,u=piv[j];bits^=b;t^=u
 assert t==0
for i in range(4):add(1<<i,1)
for i,j in enumerate(op):add((1<<i)^(1<<j),0)
for i in range(N):
 for j in range(i+1,N):
  assert set(np.flatnonzero(adj[op[i],:,op[j]]))=={op[k]for k in np.flatnonzero(adj[i,:,j])}
  for k in np.flatnonzero(adj[i,:,j]):
   a,b=map(int,(adj[i,k,j],adj[op[i],op[k],op[j]]));assert abs(a)==abs(b)
   add((1<<i)^(1<<j)^(1<<int(k)),int(a!=b))
sg=0
for j,(a,b) in sorted(piv.items()):sg|=((b+(sg&a).bit_count())%2)<<j
s=[(-1)**((sg>>j)&1)for j in range(N)]
for i in range(N):
 for j in range(N):
  assert B[i,j]==s[i]*s[j]*B[op[i],op[j]]
  assert all(int(x)*s[k]==int(y)*s[i]*s[j]for k,(x,y)in enumerate(zip(adj[i,:,j],adj[op[i],op,op[j]])))
for U,V in POLS:
 assert [op[i]for i in U]==list(V)
 assert [op[i]for i in V]==list(U)
 assert [s[i]for i in U]==[s[i]for i in V]
print('exact verified involution bracket 52² and metric 52², poles paired independently',json if False else list(zip(op,s)))
