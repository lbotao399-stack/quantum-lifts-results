"""Direct alternate endpoint/tensordot replay on independently selected chart pins."""
from pathlib import Path
import json,sys,numpy as np
from itertools import permutations
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent/'f4-j36-nested1-seal'))
from nested2_outgoing import Lo,Hi,M,R,p,chart
Y=json.loads((D/f'outgoing-{p}.json').read_text())
def parity(L):return (-1)**sum(i>j for xi,i in enumerate(L)for j in L[xi+1:])
def edge(T,A,slot):
 v=np.tensordot(A,T,axes=(1,slot))%p
 return np.moveaxis(v,0,slot)
def end(T,mat,L,mid):
 q=np.zeros_like(T)
 for a,b,c,d in permutations(range(4)):
  k=mat[a]@mat[b]-mat[b]@mat[a]
  u=edge(edge(edge(T,k,L[0]),mat[c],L[1]),mat[d],L[2])
  q+=parity((a,b,c,d))*u
 q=(q*pow(2,-1,p))%p
 J=np.zeros_like(T)
 for w in permutations(range(3)):
  z=q
  for k,j in zip(w,mid):z=edge(z,mat[k],j)
  J+=parity(w)*z
 return J%p
def cross(T,E):
 F=np.tensordot(M.reshape((26,)*4),T, axes=((2,3),E))%p
 return np.moveaxis(F,(0,1),E)
for i in list(map(int,sys.argv[1:])) or (0,49):
 seed=chart['points'][i]
 c=np.random.Generator(np.random.PCG64(144336+seed)).integers(-3,4,size=(4,52))
 X=(c@R.reshape(52,-1)).reshape(4,26,26).astype(float)%p
 # [X_i,X_j]^T = −[X_i^T,X_j^T] at left.
 L=-end(Lo,X.transpose(0,2,1),(1,0,3),(0,1,3))%p
 H=end(Hi,X,(0,2,3),(1,2,3))
 U1=cross(cross(H,(0,1)),(1,2));U2=cross(cross(H,(1,2)),(0,1))
 vals=[int(np.sum(L*U))%p for U in [U1,U2]]
 assert vals==Y[i],(i,vals,Y[i])
 print('p',p,'pin',i,'seed',seed,'values',vals,flush=True)
