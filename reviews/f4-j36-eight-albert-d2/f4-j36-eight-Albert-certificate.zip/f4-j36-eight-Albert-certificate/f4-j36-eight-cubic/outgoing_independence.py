from pathlib import Path
from itertools import combinations
import json
P=1009
D=Path(__file__).resolve().parent
X=json.loads((D/'outgoing-1009.json').read_text()); assert len(X)==703
B=json.loads((D.parent/'f4-j36-nested1-seal/BC-outgoing-1009.json').read_text());assert len(B['points'])==703
A=[[u[0],u[1],v[0]]for u,v in zip(X,B['points'])]
def det(U):
 a,b,c=U
 return sum((-1)**j*a[j]*(b[(j+1)%3]*c[(j+2)%3]-b[(j+2)%3]*c[(j+1)%3])*(-1)**j for j in range(3))
for ids in combinations(range(703),3):
 d=det([A[i]for i in ids])%P
 if d:
  o=dict(rows=ids,values=[A[i]for i in ids],det=d,prime=P)
  print(o);(D/'outgoing-independence.json').write_text(json.dumps(o)+'\n');break
else:raise AssertionError('no feasible augment')
