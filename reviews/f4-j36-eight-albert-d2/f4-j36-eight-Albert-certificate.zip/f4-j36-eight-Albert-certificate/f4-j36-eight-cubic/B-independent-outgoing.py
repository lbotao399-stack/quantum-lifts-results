"""Literal endpoint permutations and 703 transpose identity audit for B."""
from itertools import permutations
from fractions import Fraction as F
from pathlib import Path
import json,gzip, numpy as np
# Load in-house native color tensors, but not its row evaluation routine.
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'f4-j36-nested1-seal'))
from nested2_outgoing import Lo,Hi,M,R,p,chart
D=Path(__file__).parent
spect=['B',[1,0,3],[0,1,3],[0,2,3],[1,2,3]]
saved=np.array(json.loads((D/f'outgoing-{p}.json').read_text()),dtype=np.int64)[:,1]
def sign(x):return (-1)**sum(w>v for i,w in enumerate(x)for v in x[i+1:])
def factor(T,A,axis):
 S=np.tensordot(A,T,axes=([1],[axis]))%p
 return np.moveaxis(S,0,axis)
def side(A,base,ep,mp):
 B={}
 for i in range(4):
  for j in range(4):B[i,j]=(A[i]@A[j]-A[j]@A[i])%p
 S=np.zeros((26,)*4)
 for i,j,k,l in permutations(range(4)):
  # Each ordered 4-column contributes an explicit Lie bracket; normalize
  # by 2 because reversing the bracket pair is already an included slot.
  t=factor(base,B[i,j],ep[0]);t=factor(t,A[k],ep[1]);t=factor(t,A[l],ep[2])
  S=(S+sign((i,j,k,l))*t)%p
 S=(S*pow(2,-1,p))%p
 V=np.zeros((26,)*4)
 for pi in permutations(range(3)):
  t=S
  for a,i in zip(mp,pi):t=factor(t,A[i],a)
  V=(V+sign(pi)*t)%p
 return V
for point in (0,1,49,702):
 idx=chart['points'][point]
 coef=np.random.Generator(np.random.PCG64(144336+idx)).integers(-3,4,size=(4,52))
 A=((coef@R.reshape(52,-1)).reshape(4,26,26)%p).astype(float)
 # Transposed representation is anti, so its physical convention is
 # [A_i,A_j]^T = −[A_i^T,A_j^T].
 X=-side(A.transpose(0,2,1),Lo,*spect[1:3])%p
 Y=side(A,Hi,*spect[3:5])
 for pair in ((1,2),(0,1)):
  Z=np.moveaxis(Y,pair,(0,1));Y=np.moveaxis((M@Z.reshape(676,676)%p).reshape((26,)*4),(0,1),pair)
 v=int(np.sum(X.ravel()*Y.ravel()))%p
 assert v==int(saved[point]),(point,v,saved[point])
 print('literal Q0 pinned point',point,idx,v,flush=True)
A=np.frombuffer(gzip.decompress((D.parent/'f4-j36-nested1-seal'/f'selected-{p}.u16.gz').read_bytes()),dtype='<u2').reshape(703,703).astype(np.int64)
co=np.array(json.loads((D/f'coordinates-{p}.json').read_text())['coordinates'][1],dtype=np.int64)
assert np.array_equal(co@A%p,saved)
f=lambda x:F(x).numerator*pow(F(x).denominator,-1,p)%p
C=np.array([[f(v)for v in a]for a in json.loads((D.parent/'f4-j36-nested1-seal'/'trace_C4_ordered.json').read_text())['rows']],dtype=np.int64); k=co@C%p
L=tuple(map(f,('-104166480711910256640000','-17361080118651709440000','-109953507418127493120000','0')))
z=(k@L+co[700]*f('-598031033628600/7'))%p
assert z=={1009:44,1013:92}[p]
print('C4.',list(k),'nested',list(co[700:]),'corrected known section',z)
