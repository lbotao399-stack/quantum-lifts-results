"""Fresh full alternating-pole ownership control, not just a fixed coefficient."""
import native as N,json,os
from pathlib import Path
D=Path(__file__).resolve().parent
index=int(os.environ.get('CONTROL_GRAPH','13'))
g=json.loads((D/'bank-B-reduced.json').read_text())['left']['banks'][index]
args=tuple(map(tuple,g['E'])),tuple(g['d']),tuple(g['cp']),tuple(g['cm'])
cost,bits,tree=N.plan(*args);vals=[]
for b in [bits,[1]*len(bits)]:
 N.plan=lambda *z:(cost,b,tree)
 p=[N.run(g,k)for k in (0,1)]
 print(index,b,p,flush=True);vals.append(p)
assert vals[0]==vals[1]
