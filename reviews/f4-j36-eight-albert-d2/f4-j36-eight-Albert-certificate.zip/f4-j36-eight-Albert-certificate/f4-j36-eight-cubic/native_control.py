"""Replay an archived six-cubic terminal graph through the new kernel."""
import native as N, json
from pathlib import Path
G=Path(__file__).resolve().parent.parent/'f4-j36-nested1-seal'
old=json.loads((G/'nested0-calibration-bank.json').read_text())[0]
assert N.P==1009
import sys
sys.path.insert(0,str(G))
import network as O
def old_plan(E,ds,cp,cm):
 assert cp==cm==tuple(sorted(cp))
 w,b,t=O.plan(E,ds,cp)
 if os.getenv("F4_OPPOSITE_OWNERS"):b=tuple(1-i for i in b)
 return w,b,t
N.plan=old_plan
import os
j=int(os.getenv("F4_GRAPH_ID","1"));a={**old[j],'cp':old[j]['ch'],'cm':old[j]['ch']}
u=[N.run(a,i)for i in (0,1)]
x=open(G/'nested0-calibration.log').read().splitlines()
expected=[t for t in x if t.startswith(f'graph 0 {j} ')][-1].split(' poles ')[1].split(' lambda ')[0].split()
from fractions import Fraction as F
def p(f):
 v=F(f);return v.numerator*pow(v.denominator,-1,N.P)%N.P
assert u==list(map(p,expected)),(u,expected)
print('old six-cubic literal poles',u,'match',expected)
