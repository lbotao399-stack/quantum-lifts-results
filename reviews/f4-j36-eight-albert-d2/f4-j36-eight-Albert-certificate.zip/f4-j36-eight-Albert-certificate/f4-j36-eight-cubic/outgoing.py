"""Native outgoing rows for TWO genuine noncommuting, overlapping Albert exchanges."""
from pathlib import Path
import sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent/'f4-j36-nested1-seal'))
import varied_outgoing as V
import numpy as np, json
from concurrent.futures import ProcessPoolExecutor
from time import monotonic
p=V.p
specs=[('A',(0,1),(1,2)),('B',(1,2),(0,1))]
def move(T, axes):
 T=np.moveaxis(T,axes,(0,1))
 T=V.cent(V.M@T.reshape(676,676)).reshape((26,)*4)
 return np.moveaxis(T,(0,1),axes)
def ev(i):
 seed=V.chart['points'][i]
 coef=np.random.Generator(np.random.PCG64(144336+seed)).integers(-3,4,size=(4,52))
 X=(coef@V.R.reshape(52,-1)).reshape(4,26,26).astype(float)
 marks={(a,b):X[a]@X[b]-X[b]@X[a] for a,b in V.COM}
 # Same physical W1 seed construction as independently audited neighbour:
 # two endpoint alternants in phi_0,phi_1,phi_2,lambda, and two scalar
 # alternants; right supplies Psi endpoint in the input-to-Q0 formula.
 L=V.alt_mid(V.ep(1,X,marks,(1,0,3)),X.transpose(0,2,1),(0,1,3)).ravel()
 H=V.alt_mid(V.ep(0,X,marks,(0,2,3)),X,(1,2,3))
 return [int(L@move(move(H,E1),E2).ravel())%p for _,E1,E2 in specs]
if __name__=='__main__':
 start=monotonic()
 out=D/f'outgoing-{p}.json';rows=json.loads(out.read_text()) if out.exists() else []
 with ProcessPoolExecutor(max_workers=int(sys.argv[1])) as ex:
  for i,x in zip(range(len(rows),703),ex.map(ev,range(len(rows),703))):
   rows.append(x)
   if (i+1)%10==0 or i==702:
    tmp=out.with_suffix('.tmp');tmp.write_text(json.dumps(rows)+'\n');tmp.replace(out)
    print(i+1,round(monotonic()-start,2),flush=True)
 mat=np.asarray(rows,dtype=np.int64)
 A,s,dual=V.setup()
 C,det=V.er(A.T,mat); assert np.array_equal(C.T@A%p,mat.T)
 assert np.array_equal(C.T@s%p,(mat.T@dual%p)[:,0])
 (D/f'coordinates-{p}.json').write_text(json.dumps(dict(det=det, specs=specs, moments=(mat.T@dual%p).tolist(), coordinates=C.T.tolist()))+'\n')
 print(specs, (mat.T@dual%p).tolist())
