"""Independent dense ownerless native contraction of literal fixed pole occupations."""
from pathlib import Path
import numpy as np, json,os
import native as N
D=Path(__file__).parent
p=N.P
assert p in (1009,1013)
g=json.loads((D/'bank-B-reduced.json').read_text())['left']['banks'][int(os.environ.get('CONTROL_GRAPH','0'))]
E=g['E']; ds=g['d']; cp=g['cp'];cm=g['cm']; Cn=g['cubics']
G={26:(N.hI*pow(3,-1,p))%p,52:(N.Bi*pow(N.dg,-1,p))%p}
A={26:(N.DUAL[26]*pow(N.dg,-1,p))%p,52:(N.DUAL[52]*pow(N.dg,-1,p))%p}
def normalize(Z):
 return ((Z+p//2)%p-p//2).astype(float)
def do(g,POLS):
 U,V=POLS
 K={}
 for e,d in enumerate(ds):
  H=G[d]
  if e in cp:H=H@A[d][U[cp.index(e)]]%p
  if e in cm:H=H@A[d][V[cm.index(e)]]%p
  K[e]=normalize(H)
 def vertex(x):
  edges=[i for i,(a,b)in enumerate(E)if x in (a,b)]
  if x<Cn:return edges,normalize(N.C)
  props=[i for i in edges if ds[i]==26]
  if props:
   li=next(i for i in props if E[i][1]==x)
   lo=next(i for i in props if E[i][0]==x)
   fan=next(i for i in edges if i not in props)
   color=26
  else:
   fan=len(E)-1; assert fan in edges
   li=next(i for i in edges if i!=fan and E[i][1]==x)
   lo=next(i for i in edges if i!=fan and E[i][0]==x)
   color=52
  # First reshape separate color input/output/fan indices.
  return edges,normalize(N.T[color].transpose(1,2,0).transpose([ [li,lo,fan].index(i)for i in edges]))
 _,_,P=N.plan(tuple(map(tuple,E)),tuple(ds),tuple(cp),tuple(cm))
 def con(T):
  if isinstance(T,int):
   u,a=vertex(T)
   return {T},u,a
  S,x,a=con(T[0]);R,y,b=con(T[1])
  q=[i for i in x if i in y]
  for i in q:
   k=x.index(i);a1=np.moveaxis(a,k,-1)
   h=K[i] if E[i][0] in S else K[i].T
   a=np.moveaxis(normalize(a1@h),-1,k)
  z=np.tensordot(a,b,axes=([x.index(i)for i in q],[y.index(i)for i in q]))
  ib=np.prod([ds[i]for i in q],dtype=np.int64)
  assert ib*(p//2)**2<2**52
  return S|R,[i for i in x if i not in q]+[i for i in y if i not in q],normalize(z)
 Q,S,X=con(P);assert len(S)==0
 return int(X)%p
POLD=N.POLS[:]
for branch in (0,1):
 U,V=POLD[branch]
 for choice in range(2):
  if choice:U=U[1:]+U[:1];V=V[2:]+V[:2]
  a=do(g,(U,V))
  N.POLS[branch]=(U,V)
  b=N.run(g,branch,fixed=True)
  assert a==b,(branch,choice,a,b)
  print('ownerless late-bond contraction',p,branch,choice,a,flush=True)
