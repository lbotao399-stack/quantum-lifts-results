from pathlib import Path
D=Path(__file__).resolve().parent
orig=(D.parent/'f4-j36-nested1-seal/network.py').read_text()
# Keep literal metric, primitive cubic, exact pole frames, and contractions.
prefix=orig[:orig.index('def plan(')]
prefix=prefix.replace("D/'cubic.json'","D.parent/'f4-j36-nested1-seal/cubic.json'")
prefix='\n'.join(row for row in prefix.split('\n') if not row.startswith('BANK='))+'\n'
alg=orig[orig.index('def run('):orig.index("if __name__=='__main__':")]
patch={
"E,ds,ch,(_,bits,pl)=net(json.dumps(g,sort_keys=True));uu,vv=POLS[branch]":"E,ds,cp,cm=g['E'],g['d'],g['cp'],g['cm']; ch=sorted(set(cp+cm));_,bits,pl=plan(tuple(map(tuple,E)),tuple(ds),tuple(cp),tuple(cm));uu,vv=POLS[branch]",
"for u,v in product(range(6),repeat=2):\n   allEdges[i,u,v]=red(mi[d]@A[uu[u]]@A[vv[v]])":"for u,v in product(range(6) if i in cp else [-1],range(6) if i in cm else [-1]):\n   H=mi[d]\n   if u>=0:H=H@A[uu[u]]\n   if v>=0:H=H@A[vv[v]]\n   allEdges[i,u,v]=red(H)",
"i!=14":"i!=len(E)-1",
",14)":",len(E)-1)",
"j=ch.index(i);a=inc.index(i);U={}":"a=inc.index(i);U={}\n   uu_inds=list(range(6))if i in cp else [-1];vv_inds=list(range(6))if i in cm else [-1]",
"[(j,j)]":"[(cp.index(i)if i in cp else -1,cm.index(i)if i in cm else -1)]",
"([ (j,j) ] if fixed else product(range(6),repeat=2))":"([(cp.index(i)if i in cp else -1,cm.index(i)if i in cm else -1)]if fixed else product(uu_inds,vv_inds))",
"u1,v1=1<<u,1<<v":"u1,v1=(1<<u if u>=0 else 0),(1<<v if v>=0 else 0)"
}
for x,y in patch.items():alg=alg.replace(x,y)
assert 'product(uu_inds,vv_inds)' in alg
planner='''@cache
def plan(E,ds,cp,cm):
 n=1+max(map(max,E)); r=len(E);Q=1<<n
 ch=sorted(set(cp+cm))
 bd=[sum(1<<i for i,(a,b) in enumerate(E)if ((m>>a)^(m>>b))&1)for m in range(Q)]
 @cache
 def weights(w):return prod(ds[i]for i in range(r)if w>>i&1)
 parts=[[] for _ in range(Q)]
 for m in range(Q):
  if bd[m].bit_count()>5:continue
  a=(m-1)&m
  while a:
   b=m^a
   if a<b and bd[a]&bd[b] and bd[a].bit_count()<=5 and bd[b].bit_count()<=5:
    parts[m].append((a,b,weights(bd[a]|bd[b])))
   a=(a-1)&m
 best=(10**90,None,None)
 # Limited but deterministic ownership set; the chosen partition is exact
 # irrespective of benchmarking heuristic.
 masks=[0,(1<<len(ch))-1,42,21,85,51,102,76,12,66,119,13]
 if os.getenv('F4_ALL_PLANS'):masks=range(1<<len(ch))
 for ix in masks:
  bits=[ix>>j&1 for j in range(len(ch))]; own=[[0]*n,[0]*n]
  for e,s in zip(ch,bits):
   own[0][E[e][s]]+=e in cp;own[1][E[e][s]]+=e in cm
  c=[[0]*Q,[0]*Q]
  for m in range(1,Q):
   i=m&-m;u=i.bit_length()-1
   for j in range(2):c[j][m]=c[j][m^i]+own[j][u]
  dp=[10**60]*Q;ptr=[None]*Q
  for m in range(1,Q):
   if m.bit_count()==1:dp[m]=0;continue
   for a,b,cst in parts[m]:
    x,y,z,t=c[0][a],c[0][b],c[1][a],c[1][b]
    cost=dp[a]+dp[b]+cst*comb(6,x)*comb(6-x,y)*comb(6,z)*comb(6-z,t)
    if cost<dp[m]:dp[m]=cost;ptr[m]=(a,b)
  if dp[-1]<best[0] and dp[-1]<10**59:
   def parse(m):
    if m.bit_count()==1:return m.bit_length()-1
    a,b=ptr[m];return parse(a),parse(b)
   best=(dp[-1],bits,parse(Q-1))
 if best[1] is None:raise ValueError('no bounded graph plan')
 return best
'''
main='''
if __name__=='__main__':
 tag,side=sys.argv[1:3]
 M=json.loads((D/f'bank-{tag}-reduced.json').read_text())[side]
 assert not M['ordinary'], 'unaccounted socket in overlap'
 G=M['banks']; total=0;start=time.monotonic()
 for i,g in enumerate(G):
  if len(sys.argv)>3 and str(i) not in sys.argv[3:]:continue
  pre=plan(tuple(map(tuple,g['E'])),tuple(g['d']),tuple(g['cp']),tuple(g['cm']))
  print('plan',i,pre,round(time.monotonic()-start,1),flush=True)
  if os.getenv('F4_PLAN_ONLY'):continue
  z=[run(g,s)for s in (0,1)];r=red(sum(x*y for x,y in zip(z,weights)))
  total=red(total+r*g['w'])
  print('graph',i,'poles',z,'weighted raw',red(r*g['w']),'total',total,'elapsed',round(time.monotonic()-start,1),flush=True)
 if not os.getenv('F4_PLAN_ONLY'):
  denom=2*F(C0['k'])**4
  result=(total*denom.denominator*pow(denom.numerator,-1,P))%P if P else total/denom
  print('scope',len(sys.argv[3:]) or len(G),'of',len(G),'score',result,flush=True)
'''
(D/'native.py').write_text(prefix+planner+alg+main)
