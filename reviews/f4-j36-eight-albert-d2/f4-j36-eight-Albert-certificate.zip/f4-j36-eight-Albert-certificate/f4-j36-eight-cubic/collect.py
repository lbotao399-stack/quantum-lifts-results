from fractions import Fraction
from pathlib import Path
import re,sys,json
D=Path(__file__).resolve().parent
p=int(sys.argv[1])
J=json.loads((D/f'coordinates-{p}.json').read_text())
for i,(tag,*_) in enumerate(J['specs']):
 word=json.loads((D/f'bank-{tag}-reduced.json').read_text())
 side='right'if 'right' in sys.argv[2:] else 'left'
 H=word[side]
 G=H['banks']; assert not H['ordinary']; W={}
 L=sorted(D.glob(f'native-{tag}-{side}-*-{p}.log'))+sorted(D.glob(f'native-{tag}-{side}-{p}.log'))
 if side=='right':
  assert all([a[k]for k in ('E','d','cp','cm','w')]==[b[k]for k in ('E','d','cp','cm','w')]
             for a,b in zip(word['left']['banks'][:12],G[:12]))
  L+=sorted(D.glob(f'native-{tag}-left-*-{p}.log'))
 for f in L:
  for k,u,v,z in re.findall(r'graph (\d+) poles \[(\d+), (\d+)\] weighted raw (\d+)',f.read_text()):
   k,u,v,z=map(int,(k,u,v,z))
   if side=='right' and '-left-'in f.name and k>=12:continue
   assert 0<=k<len(G)
   w=(-4*2392*7113106*u+2*2299*1850212*v)*G[k]['w']%p
   assert w==z
   assert k not in W or W[k]==w
   W[k]=w
 observed=len(W)
 if 'swap' in sys.argv[2:]:
  for k,g in enumerate(G):
   paired=[j for j,h in enumerate(G)if (g['E'],g['d'],g['cp'],g['cm'],g['w'])==(h['E'],h['d'],h['cm'],h['cp'],h['w'])]
   assert len(paired)==1
   j=paired[0]
   if j in W:
    assert k not in W or W[k]==W[j]
    W[k]=W[j]
 print(tag,'independent graphs',observed)
 print(tag, 'C4,nested0',J['moments'][i][1:],'projection',J['moments'][i][0],'terminal',len(W),'of',len(G),flush=True)
 if len(W)==len(G):
  assert sorted(W)==list(range(len(G)))
  d=2*Fraction(28,3)**4
  raw=sum(W.values())%p
  z=raw*d.denominator*pow(d.numerator,-1,p)%p
  r=(z-J['moments'][i][0])%p
  cert=dict(tag=tag,side=side,p=p,L=z,section=J['moments'][i][0],residual=r,raw=raw,net_count=len(W),direct_graph_count=observed)
  (D/f'comparison-{tag}-{side}-{p}.json').write_text(json.dumps(cert)+'\n')
  print(cert)
