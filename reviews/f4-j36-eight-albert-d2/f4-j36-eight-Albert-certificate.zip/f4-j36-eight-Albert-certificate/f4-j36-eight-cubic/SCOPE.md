# SO-free F4 j36 eight-cubic W1 crossings

New actual finite F4 source tensors. Pair the four external 26 rails of the
previous independent B alternants through TWO consecutive normalized **cross-channel** 26
exchanges, on overlapping pairs (01),(12) for A and (12),(01)
for B, read from right to left. No gauges changed. This is not a simulation:
C is the exact F4 cubic invariant (60 weight-eligible coefficients reduced
to one dimension, 294 support, all 52 Ward), and the normalized exchange
is the crossed color-index version of `C^† C / κ` with the native metric
and κ=28/3: the two linearly moving legs on each rail meet at a separate
cubic vertex, and a 26 propagator joins the two vertices. This invariant
M is not an idempotent in its present ordering. Each tensor thus has
eight cubic vertices (12 edges before fans), rather than six; the candidate
is not assumed classically closed before subtracting its exact physical
outgoing section. The unmarked endpoint alternants are PU-style 4-letter
determinants; Q0 puts a scalar bracket into each. In the source itself
the right bracket is one physically ψ-marked site, not two ψ.

Both tested words use different, overlapping pairs of rails, and their
order genuinely differs: M01 M12 is not equal to M12 M01. These are two
tested geometries, not an assertion that the two finite Q0 classes
differ in the quotient. Both native Q0 rows are sampled on the same
703 selected points (exact modular binary-integer accumulators guarded
against magnitudes above 2^53). For final interpolation use chosen
physical five trace controls and known nested scores, not old uncorrected
irrep trace scores; see signed bridge note.

Exact return construction:
- With two disjoint Q1 fans, resulting trivalent network has 12 vertices
  18 edges and exactly seven independent cycles. Each dotted species
  has six insertions. On the graphic quotient compute the two separate
  6-by-6 Plücker coefficients for every pair of omitted chords.
- With an overlapping second mark only the first fan exists before the
  η contraction. This network has 10 vertices, 15 edges, six independent
  cycles; the two coefficients are separate 5-by-5 minors. Keeping only
  the first five chord columns is invalid, even though it returns zero
  for A. Carry each pair of omissions as separate channels through
  rational Ward movement of scalar spectators. In every tested A channel,
  scalar residual vanishes after exact SU3 alternating projection; the
  scalar commutator remainder is replaced by its actual ψ parent, and
  the η Q0 = λ Q1 identity puts the last fan on that parent. Chord sets
  cp,cm now each have 6 edges, with second fan inserted in both.
- Typed graph compiler uses directed terminal Lie vertices, ordered ghost
  occupations, and each exact incidence minor (totally unimodular). Graph
  contractions carry plus/minus exterior masks independently (0 contributes
  when one site is unoccupied) and exact native polar matrix contractions.
  Corrected B-left graph 8 was checked independently: weighted raw 276,
  raw poles (406,987) modulo 1009. This is one graph, not the whole score.
- A exact topology: 72 nonzero signed raw disjoint word channels; 18/54
  overlap bracket tapes with left/right first mark; 18/30 oriented
  final graphs after literal signed summing. Nothing ordinary remains
  after exact SU3 alternating projection on each omission pair. Both
  marks agree only after summing all actual graph values; not asserted
  before full replay.

Reconstruction: install the archived `f4-j36-nested1-seal/` invariant
fixture, its B-exact-typed-replay.js, previous network.py, and binary 703
chart files adjacent; expand current source archive in its own directory.
`python export_typed.py; node typed.js A >typed-A.correct.json`; same B;
`python build_bank.py A; python reduce_native.py A`; likewise B.
`python export_contraction.py; OPENBLAS_NUM_THREADS=1 P=1009 python -u native.py A left`.
Subset graph IDs, in argv after first-mark side, are supported; combine
literal weighted raw residues from every index before dividing by
2 κ^4. Outgoing batch `OPENBLAS_NUM_THREADS=1 python -u outgoing.py 1`
resumes existing output points; set F4_CAL_PRIME=1013 for independent
prime. Do not run multiple writers on a given prime. No nonzero
differential claimed from structural tape or partial scores.
