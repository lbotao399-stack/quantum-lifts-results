from pathlib import Path
import json,re,sys
D=Path(__file__).resolve().parent
old=(D.parent/'f4-j36-nested1-seal/B-exact-typed-replay.js').read_text()
raw=json.loads(re.search(r'^const raw=Function\((".*?")\)\(\);',old)[1])
ward=json.loads(re.search(r'const ward=Function\("z",(".*?")\)\(raw\);',old)[1])
def rep(a,b):
 global raw
 assert raw.count(a)==1,(a,raw.count(a))
 raw=raw.replace(a,b)
rep('...(a<2?[-a-1]:[])','...EX.flatMap((ab,j)=>ab.includes(a)?[-1-2*j-ab.indexOf(a)]:[])')
rep('const AX=','const EX=process.argv[2]==="B"?[[1,2],[0,1]]:[[0,1],[1,2]];\nconst AX=')
rep('[x,6+j]','[x,8+j]');rep('3-x','3-x')
rep('E.push([4,5],...fans.map','E.push([4,5],[6,7],...fans.map');rep('const nv=6+act.length','const nv=8+act.length')
rep('const d=s*[3,4].reduce((v,r)=>v*det(g.K,Q.filter(x=>x[2]===r).map(x=>x[0])),1)\n  fn(Q,d)',"""const D=[3,4].map(r=>g.chords.map((_,drop)=>{
   const ID=Q.filter(x=>x[2]===r).map(x=>x[0]);
   return det(g.K.map(X=>X.filter((_,j)=>j!==drop)),ID)
  }));
  for(let a=0;a<7;a++)if(D[0][a])for(let b=0;b<7;b++)if(D[1][b])fn(Q,s*D[0][a]*D[1][b],a,b)""")
rep('[[11,0,3],[11,1,4]]','[[14,0,3],[14,1,4]]')
rep('[[13,0,3],[13,1,4]]:i===6?[[14,0,3],[14,1,4]]','[[16,0,3],[16,1,4]]:i===6?[[17,0,3],[17,1,4]]')
rep('returned(x,g,r3,(Q,d)=>','returned(x,g,r3,(Q,d,a,b)=>')
rep("const k=sk.map(x=>[x[0],x[2]]).join(':');W[k]=(W[k]||0)+c*d;bank[k]=[g.E,g.chords]","const k=[a,b].join(':')+';'+sk.map(x=>[x[0],x[2]]).join(':');W[k]=(W[k]||0)+c*d;bank[k]=[g.E,g.chords]")
# Both disjoint and overlapping use one fewer ghost of each dot than beta_1.
rep('for(let a=0;a<7;a++)if(D[0][a])for(let b=0;b<7;b++)','for(let a=0;a<g.chords.length;a++)if(D[0][a])for(let b=0;b<g.chords.length;b++)')
rep('returned(x,g,r2,(Q,d)=>','returned(x,g,r2,(Q,d,a,b)=>')
rep("const id=[j,k].join(':');","const id=[j,k,a,b].join(':');")
ward=ward.replace("t<8","t<12")
ward=ward.replace("return Object.fromEntries(['left','right'].map(k=>[k,reduce(z[k])]))","""return Object.fromEntries(['left','right'].map(k=>{
 const groups={};
 for(const [w,v] of Object.entries(z[k].weighted)){
  const [u,m]=w.split(';');const J=groups[u]??={weighted:{},bank:{}};
  J.weighted[m]=v;J.bank[m]=z[k].bank[w];
 }
 return [k,Object.fromEntries(Object.entries(groups).map(([u,g])=>[u,reduce(g)]))];
}));""")
# det() originally assumes one naturally integral pivot. Graphic incidence
# minors are still totally unimodular after restricting the chord columns.
out='const raw=Function('+json.dumps(raw)+')();\nconst W=Function("z",'+json.dumps(ward)+')(raw);\nconsole.log(JSON.stringify({raw,W}));\n'
(D/'typed.js').write_text(out)
