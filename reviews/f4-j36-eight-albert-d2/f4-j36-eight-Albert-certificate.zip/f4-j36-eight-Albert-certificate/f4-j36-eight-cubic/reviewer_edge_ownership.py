"""Changes only ownership of a decorated edge, not graph, masks, or contraction tree.

Each decorated edge stands for L[a] H[a,b] R[b]. Assigning H to L means
L[a] @ H[a,b], assigning to R means R[b] @ H.T[b,a]. The final graph
must be independent of this choice. Fixed 12 ghost assignments and
multi-edge probe make this an inexpensive regression, not a d2 score.
"""
import native as N
import json
from pathlib import Path
from functools import cache
G=json.loads((Path(__file__).parent/'bank-B-reduced.json').read_text())['left']['banks']
P=N.P
original=N.plan
for e in (1,2,8,10):
 g=G[e]
 E,ds,cp,cm=tuple(map(tuple,g['E'])),tuple(g['d']),tuple(g['cp']),tuple(g['cm'])
 assert sorted(cp)==list(cp) and sorted(cm)==list(cm)
 cost,bits,tree=original(E,ds,cp,cm)
 ix=sorted(set(cp+cm))
 assert len(ix)==len(bits)
 scores=[]
 variants=[bits,tuple(1-b for b in bits),[0]*len(ix),[1]*len(ix)]
 for x in variants:
  N.plan=lambda *unused: (cost,x,tree)
  scores.append(N.run(g,0,True))
 print(e,P,bits,'fixed coefficient under four ownership maps',scores,flush=True)
 assert len(set(scores))==1,(e,scores)
N.plan=original
