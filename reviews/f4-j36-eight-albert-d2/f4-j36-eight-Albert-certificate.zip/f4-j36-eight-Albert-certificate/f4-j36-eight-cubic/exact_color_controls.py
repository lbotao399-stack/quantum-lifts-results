"""Finite intertwiner idempotence checks, independently of the return graph bank."""
from outgoing import V,move,ev,D
from itertools import product
import numpy as np,json
p=V.p
M=V.M.astype(np.int64)
assert not np.array_equal((M@M)%p,M%p)
raw=M.reshape((26,)*4).transpose(0,2,1,3)
# Undo the color-index crossing and move the raised index on the second
# pair to the first pair. V.act acts in the stated slots, modulo p.
H=(V.b.N.h%p).astype(float)
HI=V.b.hI.astype(float)
P=V.cent(V.act(HI,V.act(H,raw.astype(float),2),1)).reshape(676,676).astype(np.int64)
assert np.array_equal(P@P%p,P%p)
assert sum(int(P[i,i])for i in range(676))%p==26
u=np.zeros((26,)*4);u[4,0,25,3]=1
a=move(move(u,(0,1)),(1,2));b=move(move(u,(1,2)),(0,1))
d=(a-b)%p
i=np.nonzero(d)
assert len(i[0])>0
v=ev(0); assert v==json.loads((D/f'outgoing-{p}.json').read_text())[0]
print('p',p,'direct P²=P mod p, trace 26; cross exchange M²≠M; commutator nonzero entries',len(i[0]),'first',tuple(int(j[0])for j in i),'value',int(d[tuple(j[0]for j in i)]),'outgoing0',v)
