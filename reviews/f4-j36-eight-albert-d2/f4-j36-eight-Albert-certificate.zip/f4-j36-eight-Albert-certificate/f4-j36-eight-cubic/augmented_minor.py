"""Literal 704x704 augmented minor on the exact physical section."""
import json,numpy as np
from outgoing import D,p,V
A,s,_=V.setup()
J=json.loads((D/f'comparison-B-left-{p}.json').read_text())
Y=np.asarray(json.loads((D/f'outgoing-{p}.json').read_text()))[:,1]
F=np.block([[A,s[:,None]],[Y[None,:],np.asarray([[J['L']]],dtype=np.int64)]])
assert F.shape==(704,704)
# Main chart order, append candidate row & obstruction column after the 703.
_,z=V.er(F,np.eye(704,dtype=np.int64)[:,:1])
assert z==({1009:1005,1013:734}[p]*J['residual'])%p
print(f'p={p}: actual augmented determinant {z}')
