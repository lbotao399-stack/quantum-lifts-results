# Exact paired dotted occupancy reduction at the terminal covector

Within each oriented A/B and left/right graph bank, the terminal terms pair
under `(cp,cm) -> (cm,cp)`, with literal E,d,w unchanged. Since each
species has six odd insertions, swapping the two ordered 6-lists
has exterior sign `(-1)^(6*6)=+1`; the relative order within each list is
unchanged. On common edges this exchanges the ordering of the (+) and (-)
matrix insertions along the edge. The graded commutation needed to
restore the chosen common-edge order is exact under the terminal covector:
the additional graded bracket of the two first ghosts is the Q0 of the
mixed second jet of the relative ghost, and **all remaining inserted
letters are closed first ghosts**. Q0 of this complete invariant
color-decorated graph is exactly the bracket graph (no spectator spill).
Thus this step uses actual boundaries and (λ Q0=0), not a bare ideal.
It need not fix each separate raw pole evaluation.

The two native pole pairs each get exchanged in order by an actual
metric-preserving involutive F4 automorphism. `chevalley_swap.py`
constructs its signed basis permutation by solving every sparse bracket
equation over GF(2) and checks all 52² literal brackets and all 52² metric
entries over integers. The product of all scalar root signs on the
paired six-tuples is +1 because the automorphism is an involution and
both tuples map index-for-index to the other. The F4 Dynkin diagram has
no outer automorphism: the Lie algebra automorphism is inner, so its
action on the 26 preserves the literal cubic when lifted by the connected
group. Full network equivariance follows; in particular the two native
pole projections induce the same weighted λ score on the graded-swapped
graphs after the exact common-edge correction above. Combined with the
first-ghost boundary argument, mirrored graph weights can thus be
doubled in the *physical terminal λ certificate*, not at an individual
pole. `collect.py ... swap` tests pairing on literal graph records and
checks all overlap actually computed twice; fills only certified mirrors.

Independent corrected p1009 B-left mirror controls on graphs 12↔15,
13↔16 and 14↔17 give weighted raw values 633, 476 and 138, respectively.
Individual pole pairs differ. The final native λ combination is what
coincides, as required. Both sets of corrected logs are included.
