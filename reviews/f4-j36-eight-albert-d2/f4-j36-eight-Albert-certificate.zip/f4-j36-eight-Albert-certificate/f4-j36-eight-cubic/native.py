"""Exact numerator contraction on a six-chord, six-Albert terminal network."""
from pathlib import Path
from itertools import product
from collections import defaultdict
from functools import cache
from math import prod,lcm,comb
from fractions import Fraction as F
import numpy as np,json,time,sys,os
D=Path(__file__).resolve().parent
J=json.loads((D.parent/'fixtures/color-basis-native.json').read_text())
C0=json.loads((D.parent/'f4-j36-nested1-seal/cubic.json').read_text())
P=int(os.getenv('P','0'))
def gram(N,data):
 den=lcm(*(F(v).denominator for *_,v in data))
 m=np.zeros((N,N),dtype=np.int64)
 for i,j,v in data:m[i,j]=int(den*F(v))
 return den,m
_,h=gram(26,J['representationInvariantForm']);hI=3*h.copy();hI[:2,:2]=[[2,1],[1,2]]
_,B=gram(52,J['metric']);dg,Bi=gram(52,J['inverseMetric'])
assert np.array_equal(h@hI,3*np.eye(26,dtype=np.int64))
assert np.array_equal(B@Bi,dg*np.eye(52,dtype=np.int64))
rep=np.zeros((52,26,26),dtype=np.int64);adj=np.zeros((52,52,52),dtype=np.int64)
for p,rr in enumerate(J['representation26']):
 for x,y,z in rr:rep[p,x,y]=int(z)
for x,y,t in J['bracketPairs']:
 for k,z in t:adj[x,k,y]=int(z);adj[y,k,x]=-int(z)
T={26:rep.transpose(0,2,1)@h,52:adj.transpose(0,2,1)@B}
assert all(not np.any(t+t.transpose(0,2,1))for t in T.values())
DUAL={d:(Bi@r.reshape(52,-1)).reshape(52,d,d).transpose(0,2,1)for d,r in [(26,rep),(52,adj)]}
mi={26:hI,52:Bi}
C=np.zeros((26,)*3,dtype=np.int64)
for x,y,z,v in C0['cubic']:C[x,y,z]=v
weights=[-4*2392*7113106,2*2299*1850212]
POLS=[((19,29,31,45,46,47),(42,18,17,12,11,9)),((19,20,29,45,46,47),(42,39,18,12,11,9))]
red=lambda x:x%P if P else x
def act(X,H,i):
 Y=np.moveaxis(X,i,-1);sh=Y.shape
 assert sh[-1]*int(np.max(np.abs(Y)))*int(np.max(np.abs(H)))<2**63
 return np.moveaxis(red(Y.reshape(-1,sh[-1])@H).reshape(*sh[:-1],H.shape[-1]),-1,i)
def alt(a,b):return (-1)**sum((b&((1<<i)-1)).bit_count()for i in range(6)if a>>i&1)
sign={(a,b):alt(a,b)for a in range(64)for b in range(64)if not a&b}
COMP={(a,b):comb(6,a)**2*comb(6-a,b)**2 for a in range(7)for b in range(7-a)}

@cache
def plan(E,ds,cp,cm):
 n=1+max(map(max,E)); r=len(E);Q=1<<n
 ch=sorted(set(cp+cm))
 bd=[sum(1<<i for i,(a,b) in enumerate(E)if ((m>>a)^(m>>b))&1)for m in range(Q)]
 @cache
 def weights(w):return prod(ds[i]for i in range(r)if w>>i&1)
 parts=[[] for _ in range(Q)]
 for m in range(Q):
  if bd[m].bit_count()>5:continue
  a=(m-1)&m
  while a:
   b=m^a
   if a<b and bd[a]&bd[b] and bd[a].bit_count()<=5 and bd[b].bit_count()<=5:
    parts[m].append((a,b,weights(bd[a]|bd[b])))
   a=(a-1)&m
 best=(10**90,None,None)
 # Limited but deterministic ownership set; the chosen partition is exact
 # irrespective of benchmarking heuristic.
 masks=[0,(1<<len(ch))-1,42,21,85,51,102,76,12,66,119,13]
 if os.getenv('F4_ALL_PLANS'):masks=range(1<<len(ch))
 for ix in masks:
  bits=[ix>>j&1 for j in range(len(ch))]; own=[[0]*n,[0]*n]
  for e,s in zip(ch,bits):
   own[0][E[e][s]]+=e in cp;own[1][E[e][s]]+=e in cm
  c=[[0]*Q,[0]*Q]
  for m in range(1,Q):
   i=m&-m;u=i.bit_length()-1
   for j in range(2):c[j][m]=c[j][m^i]+own[j][u]
  dp=[10**60]*Q;ptr=[None]*Q
  for m in range(1,Q):
   if m.bit_count()==1:dp[m]=0;continue
   for a,b,cst in parts[m]:
    x,y,z,t=c[0][a],c[0][b],c[1][a],c[1][b]
    cost=dp[a]+dp[b]+cst*comb(6,x)*comb(6-x,y)*comb(6,z)*comb(6-z,t)
    if cost<dp[m]:dp[m]=cost;ptr[m]=(a,b)
  if dp[-1]<best[0] and dp[-1]<10**59:
   def parse(m):
    if m.bit_count()==1:return m.bit_length()-1
    a,b=ptr[m];return parse(a),parse(b)
   best=(dp[-1],bits,parse(Q-1))
 if best[1] is None:raise ValueError('no bounded graph plan')
 return best
def run(g,branch,fixed=False):
 E,ds,cp,cm=g['E'],g['d'],g['cp'],g['cm']; ch=sorted(set(cp+cm));_,bits,pl=plan(tuple(map(tuple,E)),tuple(ds),tuple(cp),tuple(cm));uu,vv=POLS[branch]
 owner={e:E[e][s] for e,s in zip(ch,bits)}
 allEdges={}
 for i in ch:
  d=ds[i];A=DUAL[d]
  for u,v in product(range(6) if i in cp else [-1],range(6) if i in cm else [-1]):
   H=mi[d]
   if u>=0:H=H@A[uu[u]]
   if v>=0:H=H@A[vv[v]]
   allEdges[i,u,v]=red(H)
 def leaf(x):
  inc=tuple(i for i,(s,t) in enumerate(E)if x in (s,t))
  if x<g.get('cubics',6):X=C.copy()
  else:
   if any(ds[i]==26 for i in inc):
    d=26
    cov=(next(i for i in inc if ds[i]==26 and E[i][1]==x),next(i for i in inc if ds[i]==26 and E[i][0]==x),next(i for i in inc if ds[i]==52))
   else:
    d=52
    cov=(next(i for i in inc if i!=len(E)-1 and E[i][1]==x),next(i for i in inc if i!=len(E)-1 and E[i][0]==x),len(E)-1)
   X=np.moveaxis(T[d],0,-1).transpose([cov.index(i)for i in inc]).copy()
  for a,i in enumerate(inc):
   if i not in ch and E[i][0]==x:X=act(X,mi[ds[i]],a)
  take=tuple(i for i in inc if owner.get(i)==x);R={(0,0):X}
  for i in take:
   a=inc.index(i);U={}
   uu_inds=list(range(6))if i in cp else [-1];vv_inds=list(range(6))if i in cm else [-1]
   for u,v in ([(cp.index(i)if i in cp else -1,cm.index(i)if i in cm else -1)]if fixed else product(uu_inds,vv_inds)):
    u1,v1=(1<<u if u>=0 else 0),(1<<v if v>=0 else 0)
    H=allEdges[i,u,v];H=H if E[i][0]==x else H.T
    for (b,c),Y in R.items():
     if b&u1 or c&v1:continue
     k=(b|u1,c|v1)
     z=act(Y,H,a)*sign[b,u1]*sign[c,v1]
     U[k]=red(z+(U[k]if k in U else 0))
   R=U
  out={}
  for p,Q in R.items():
   i=np.nonzero(Q)
   if len(i[0]):out[p]=dict(zip(zip(*(map(int,r)for r in i)),map(int,Q[i])))
  return inc,out
 def split(R,side,mid):
  out={}
  for a,G in R.items():
   j=defaultdict(list)
   for ix,n in G.items():j[tuple(ix[i]for i in mid)].append((tuple(ix[i]for i in side),n))
   out[a]=j
  return out
 def con(t):
  if isinstance(t,int):return leaf(t)
  (a,X),(b,Y)=map(con,t)
  g=tuple(i for i in a if i in b);l=tuple(i for i in a if i not in g);r=tuple(i for i in b if i not in g)
  L=split(X,[a.index(i)for i in l],[a.index(i)for i in g]);del X
  R=split(Y,[b.index(i)for i in r],[b.index(i)for i in g]);del Y
  out=defaultdict(lambda:defaultdict(int))
  for (u,v),G in L.items():
   for (x,y),H in R.items():
    if u&x or v&y:continue
    D0=out[u|x,v|y];s=1 if fixed else sign[u,x]*sign[v,y]
    J=G if len(G)<=len(H)else H
    for q in J:
     if q in G and q in H:
      for i,a0 in G[q]:
       a0*=s
       for j,b0 in H[q]:D0[i+j]+=a0*b0
  o={k:{j:red(a)for j,a in H.items()if red(a)}for k,H in out.items()}
  return l+r,{k:j for k,j in o.items()if j}
 I,V=con(pl)
 assert not I
 z=V.get((63,63),{}).get((),0)
 d=3**ds.count(26)*dg**(ds.count(52)+12)
 return z*pow(d,-1,P)%P if P else F(z,d)

if __name__=='__main__':
 tag,side=sys.argv[1:3]
 M=json.loads((D/f'bank-{tag}-reduced.json').read_text())[side]
 assert not M['ordinary'], 'unaccounted socket in overlap'
 G=M['banks']; total=0;start=time.monotonic()
 for i,g in enumerate(G):
  if len(sys.argv)>3 and str(i) not in sys.argv[3:]:continue
  pre=plan(tuple(map(tuple,g['E'])),tuple(g['d']),tuple(g['cp']),tuple(g['cm']))
  print('plan',i,pre,round(time.monotonic()-start,1),flush=True)
  if os.getenv('F4_PLAN_ONLY'):continue
  z=[run(g,s)for s in (0,1)];r=red(sum(x*y for x,y in zip(z,weights)))
  total=red(total+r*g['w'])
  print('graph',i,'poles',z,'weighted raw',red(r*g['w']),'total',total,'elapsed',round(time.monotonic()-start,1),flush=True)
 if not os.getenv('F4_PLAN_ONLY'):
  denom=2*F(C0['k'])**4
  result=(total*denom.denominator*pow(denom.numerator,-1,P))%P if P else total/denom
  print('scope',len(sys.argv[3:]) or len(G),'of',len(G),'score',result,flush=True)
