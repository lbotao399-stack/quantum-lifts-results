"""Translate typed graphic reductions to unreduced native tensor-bank entries.

Variants A and B are oriented from the right to the left endpoint.  No graph
symmetry sign is factored out here; duplicates with literally identical
orientation/slot data are combined.  The two dotted species can occupy
different chord sets, recorded independently as cp and cm.
"""
import sys,json
from pathlib import Path
from collections import Counter,defaultdict
D=Path(__file__).resolve().parent

def parity(L):return (-1)**sum(x>y for i,x in enumerate(L)for y in L[i+1:])
def leave(ch,k):return [v for j,v in enumerate(ch) if j!=k]

def dis(U):
 for tag,w in U['weighted'].items():
  if not w:continue
  a,b,c,d=map(int,tag.split(':'));E,ch=U['bank'][tag]
  assert len(ch)==7 and len(E)==18
  yield dict(E=E,d=[26]*16+[52,52],cp=leave(ch,c),cm=leave(ch,d),w=-w,kind='disjoint',tag=tag,cubics=8)
def overlap(W):
 for key,V in W.items():
  a,b=map(int,key.split(':'))
  E=V['E'];ch=V['Ch']
  for q,w in V['pTerms']:
   assert len(E)==15
   newE=[];dims=[];two=[[],[]];fl=[]
   for i,(x,y)in enumerate(E):
    col=52 if i==14 else 26
    for ii,n in enumerate((a,b)):
     if i in leave(ch,n):two[ii].append(len(newE))
    for j in q[i]:
     k=10 if isinstance(j,list) else 11
     assert len(fl)<2
     fl.append((k,j));newE.append([x,k]);dims.append(col);x=k
    newE.append([x,y]);dims.append(col)
   assert set(k for k,_ in fl)=={10,11}
   t=dict(fl)
   for l in two:l.append(len(newE))
   newE.append([10,11]);dims.append(52)
   assert len(newE)==18 and all(len(l)==6 for l in two)
   yield dict(E=newE,d=dims,cp=two[0],cm=two[1],w=w*parity(t[10]+[t[11]]),kind='overlap',tag=[a,b,q],cubics=8)

def combine(G):
 by={}
 for z in G:
  k=json.dumps([z[v]for v in ('E','d','cp','cm')],separators=(',',':'))
  if k not in by:by[k]={**z,'orig':[],'w':0}
  v=by[k];v['w']+=z['w'];v['orig'].append([z['kind'],z['tag'],z['w']])
 return [z for z in by.values()if z['w']]
if __name__=='__main__':
 i=sys.argv[1]
 j=json.loads((D/f'typed-{i}.correct.json').read_text())
 g,W=j['raw'],j['W']
 q={}
 for mode in ('left','right'):
  U={k:v['altResidual']for k,v in W[mode].items()if v['altResidual']}
  a=list(dis(g['disjoint']));b=list(overlap(W[mode]));z=combine(a+b)
  # Never score without marking uncovered ordinary residues.
  q[mode]=dict(ordinary=U,banks=z)
  print(mode,'raw dis+over',len(a),len(b),'combined',len(z),'open ordinary',len(U),sum(map(len,U.values())))
 (D/f'bank-{i}.json').write_text(json.dumps(q,separators=(',',':'))+'\n')
