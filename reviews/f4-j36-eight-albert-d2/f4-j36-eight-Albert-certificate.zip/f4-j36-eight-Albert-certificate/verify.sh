#!/bin/sh
set -eu
cd "$(dirname "$0")"
if command -v sha256sum >/dev/null 2>&1; then
    sha256sum -c SHA256SUMS >/dev/null
else
    shasum -a 256 -c SHA256SUMS >/dev/null
fi
# The collector writes comparison JSON, so run numerics in a disposable copy.
scratch="$(mktemp -d "${TMPDIR:-/tmp}/f4-eight-verify.XXXXXX")"
trap 'rm -rf "$scratch"' EXIT HUP INT TERM
cp -R f4-j36-eight-cubic f4-j36-nested1-seal fixtures "$scratch/"
cd "$scratch/f4-j36-eight-cubic"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
py="${PYTHON:-python3}"
"$py" collect.py 1009 swap
"$py" collect.py 1009 swap right
"$py" collect.py 1013 swap
"$py" - <<'PY'
import json
from pathlib import Path
expected = [('left', 1009, 361, 663, 44, 619), ('right', 1009, 361, 663, 44, 619),
            ('left', 1013, 850, 457, 92, 365)]
for side,p,*goal in expected:
 j=json.loads(Path(f'comparison-B-{side}-{p}.json').read_text())
 assert [j[k] for k in ('raw','L','section','residual')]==goal
PY
for p in 1009 1013; do
    F4_CAL_PRIME="$p" "$py" augmented_minor.py
    P="$p" "$py" reviewer_edge_ownership.py
    F4_CAL_PRIME="$p" "$py" B-independent-outgoing.py
done
