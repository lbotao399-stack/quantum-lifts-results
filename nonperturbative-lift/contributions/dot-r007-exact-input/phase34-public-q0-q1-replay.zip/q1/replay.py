"""Offline exact Phase33 Q1 bridge/replay. Python standard library only."""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
import gzip,hashlib,json,resource,sys,time
root=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(180,180))
for line in (root/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1)
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
sys.path.insert(0,str(root/'vendor'))
from fortuity.full.words import canon_word,canon_multi
from fortuity.full.letters import charges2
from fortuity.full.q1 import Q1_multi
def canonical(traces):
 sign=1;W=[]
 for tr in traces:
  s,w=canon_word(tr)
  if not s:return 0,None
  sign*=s;W.append(w)
 s,w=canon_multi(tuple(W));return sign*s,w
def word(w):return tuple(tuple((a,b,tuple(S)) for a,b,S in tr) for tr in w)
t=time.monotonic();raw=json.loads((root/'input/dmk_o330_hw.json').read_text())
assert len(raw['terms'])==6139
letters=[(0,0,(m,)) for m in range(3)]+[(0,0,tuple(i for i in range(3) if i!=m)) for m in range(3)]
O=defaultdict(F)
for c,w in raw['terms']:
 s,W=canonical(tuple(tuple(letters[L] for L in tr) for tr in w))
 if s:O[W]+=F(c)*s*(-1)**sum(L==4 for tr in w for L in tr)
O={w:c for w,c in O.items() if c};assert len(O)==6139
assert {tuple(sum(charges2(L)[i] for tr in w for L in tr) for i in range(5)) for w in O}=={(5,5,14,8,8)}
C=defaultdict(F)
for w,c in O.items():
 s=(-1)**sum(len(tr)+sum(len(L[2])%2==0 for L in tr)*(sum(len(L[2])%2==0 for L in tr)-1)//2 for tr in w)
 a,W=canonical(tuple(tuple(reversed(tr)) for tr in w))
 if a:C[W]+=a*s*c
assert {w:c for w,c in C.items() if c}=={w:-c for w,c in O.items()}
Z=defaultdict(F)
for w,c in O.items():
 for v,d in Q1_multi(w,3).items():Z[v]+=c*d
 assert len(Z)<=300000,'sparsity guard'
Z={w:c for w,c in Z.items() if c}
with gzip.open(root/'input/Q1.json.gz','rt') as f:R={word(w):F(c) for c,w in json.load(f)['terms']}
assert len(R)==213104 and Z==R
semantic=json.dumps([[str(c),w] for w,c in sorted(Z.items())],separators=(',',':')).encode()
print(json.dumps({'status':'PASS_EXACT_ALL_COEFFICIENTS','source_terms':len(O),'Q1_terms':len(Z),'C':-1,'semantic_Q1_sha256':hashlib.sha256(semantic).hexdigest(),'seconds':time.monotonic()-t,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},sort_keys=True))
