Phase33 exact SU3 R007 Q1 replay, PUBLIC INPUTS ONLY.
Run: python3 -B replay.py
Requires Python >=3.10 on Linux/Unix; standard library only, no network.
Limits: 4 GiB address space, 180 CPU seconds, 300000 sparse intermediate words.
Checks input SHA256, exact 6139-term bridge, charges, C=-1 and all213104 Q1 rational coefficients.

Bare source and all vendor files: davidsd/fortuity-ai commit4256f207986029540060fb44dd494746828f65ce.
Bare path data/su3/dmk_o330_hw.json. Vendor paths code/fortuity/full/{q1,words,letters}.py.
Reference Q1: lbotao399-stack/quantum-lifts-results frozen checkout c28f7b67c0cfa533ee1039e909a5ee2a82404591,
algorithms/su3_independent_prime_20261118/quantum_source/Q1.json.gz.

Conventions: phi_m -> C_{m}; psi_m -> (-1)^m C_{complement m}, m=0,1,2.
Canonicalize each graded cyclic trace BEFORE sorting trace factors.
Vendor Q1 is ONLY for derivative-free input pairs; K=1 in its documented kernel.
This packet matches the public archived RHS at normalization1; it does not derive the physical coupling factor,
implement derivative-dressed Q1, construct O1, or test d2. No private data/imports/credentials.
No generated output file is required: replay prints a JSON receipt. Semantic hash is deterministic;
time and RSS fields vary. The ZIP metadata and allowlist are fixed for portable byte-level checks.
