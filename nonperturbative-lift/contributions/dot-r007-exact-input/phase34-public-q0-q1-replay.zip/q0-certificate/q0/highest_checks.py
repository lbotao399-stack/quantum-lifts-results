from pathlib import Path
import sys,json,time,resource,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from fortuity.bmn import dmk
from fortuity.bmn.words import Q_expr
from finite_colour import evaluate,trace
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(300,300))
cases=[('r12_03',(2,2,2)),('r12_11',(0,2)),('r12_22',(0,0,2,2)),('r14_13',(0,2,2,2)),('r16_01',(2,)),('r16_23',(0,0,2,2,2))]
out=[];root=Path(__file__).resolve().parent;t=time.monotonic()
for name,I in cases:
 a=dmk.tensor(name)(*I);b=dmk.tensor(dmk.R_OF_r[name])(*I)
 D=dmk.add((1,Q_expr(a)),(-1,b));E=evaluate(D)
 rec={'name':name,'highest_indices':I,'formal_difference_terms':len(D),'generic_colour_terms':len(E),'seconds':time.monotonic()-t,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 assert not E,rec
 out.append(rec);print(rec,flush=True)
 (root/'highest-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
 trace.cache_clear()
print('PASS_ALL_SIX_EXACT_GENERIC_COLOUR',flush=True)
