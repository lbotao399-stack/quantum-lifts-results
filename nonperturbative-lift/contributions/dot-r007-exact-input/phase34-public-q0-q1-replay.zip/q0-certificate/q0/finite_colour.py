"""Exact generic traceless 3x3 matrices, 24 even and 24 exterior generators."""
from collections import defaultdict
from functools import lru_cache
from fractions import Fraction
from math import lcm
from itertools import product

def mul(A,B):
    out=defaultdict(int)
    for x,c in A.items():
        ox=tuple(i for i in x if i>=24)
        for y,d in B.items():
            oy=tuple(i for i in y if i>=24)
            if set(ox).intersection(oy):continue
            s=-1 if sum(i>j for i in ox for j in oy)%2 else 1
            out[tuple(sorted(x+y))]+=s*c*d
    return {w:c for w,c in out.items() if c}

def entry(L,a,b):
    # Per letter: independent diagonal 00,11 and six ordered off-diagonals.
    if a==b:
        return {(8*L+a,):1} if a<2 else {(8*L,):-1,(8*L+1,):-1}
    ix=((0,1),(0,2),(1,0),(1,2),(2,0),(2,1)).index((a,b))+2
    return {(8*L+ix,):1}

@lru_cache(None)
def trace(w):
    out=defaultdict(int)
    for idx in product(range(3),repeat=len(w)):
        P={():1}
        for k,L in enumerate(w):
            P=mul(P,entry(L,idx[k],idx[(k+1)%len(w)]))
            if not P:break
        for x,c in P.items():out[x]+=c
    return {w:c for w,c in out.items() if c}

def evaluate(expr):
    den=lcm(*(Fraction(c).denominator for c in expr.values()))
    out=defaultdict(int)
    for w,c in expr.items():
        P={():1}
        for t in w:
            P=mul(P,trace(t))
            if not P:break
        for x,d in P.items():out[x]+=int(c*den)*d
    return {w:Fraction(c,den) for w,c in out.items() if c}
