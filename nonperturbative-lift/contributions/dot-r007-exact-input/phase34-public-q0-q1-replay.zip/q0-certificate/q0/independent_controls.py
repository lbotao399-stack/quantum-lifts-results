"""Independent exterior bitmask matrix evaluator and noncommutative equivariance."""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
import sys,json,time,resource
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from fortuity.bmn import dmk
from fortuity.bmn.words import Q_expr,QLET
from finite_colour import evaluate
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(120,120))
def pmul(A,B):
 out=defaultdict(int)
 for a,c in A.items():
  for b,d in B.items():
   if a&b:continue
   inv=sum((b&((1<<i)-1)).bit_count() for i in range(a.bit_length()) if (a>>i)&1)
   out[a|b]+=c*d*(-1 if inv%2 else 1)
 return {a:c for a,c in out.items() if c}
def matrices(N):
 mats=[]
 for L in range(6):
  A=[[{} for j in range(N)] for i in range(N)];k=0
  for i in range(N):
   for j in range(N):
    if (i,j)==(N-1,N-1):continue
    if L<3:A[i][j]={0:(L+2)*(i+1)**2+(j+2)**3+(L+1)*i*j}
    else:A[i][j]={1<<((L-3)*(N*N-1)+k):1}
    k+=1
  last=defaultdict(int)
  for i in range(N-1):
   for m,c in A[i][i].items():last[m]-=c
  A[-1][-1]=dict(last);mats.append(A)
 return mats
def point(expr,N):
 mats=matrices(N);cache={};out=defaultdict(F)
 def tr(w):
  if w in cache:return cache[w]
  A=[[{0:1} if i==j else {} for j in range(N)] for i in range(N)]
  for L in w:
   B=[[defaultdict(int) for j in range(N)] for i in range(N)]
   for i in range(N):
    for j in range(N):
     for k in range(N):
      for m,c in pmul(A[i][k],mats[L][k][j]).items():B[i][j][m]+=c
   A=B
  res=defaultdict(int)
  for i in range(N):
   for m,c in A[i][i].items():res[m]+=c
  cache[w]={m:c for m,c in res.items() if c};return cache[w]
 for w,c in expr.items():
  P={0:1}
  for t in w:P=pmul(P,tr(t))
  for m,v in P.items():out[m]+=c*v
 return {m:c for m,c in out.items() if c}
def rawE(A,i,j):
 out=defaultdict(int)
 for w,c in A.items():
  for a,L in enumerate(w):
   if L==j:K,s=i,1
   elif L==i+3:K,s=j+3,-1
   else:continue
   out[w[:a]+(K,)+w[a+1:]]+=c*s
 return {w:c for w,c in out.items() if c}
def rawQ(A):
 out=defaultdict(int)
 for w,c in A.items():
  for a,L in enumerate(w):
   s=(-1)**sum(3<=z<=5 for z in w[:a])
   for d,v in QLET.get(L,[]):out[w[:a]+v+w[a+1:]]+=c*s*d
 return {w:c for w,c in out.items() if c}
t=time.monotonic()
for i in range(3):
 for j in range(3):
  if i==j:continue
  for L in range(6):assert rawE(rawQ({(L,):1}),i,j)==rawQ(rawE({(L,):1},i,j))
CH={((0,0,0,0),):F(1),((0,0),(0,0)):F(-1,2)}
assert not evaluate(CH) and not point(CH,3) and point(CH,4)
assert evaluate({((0,0),):F(1)})
# Highest r12_03 relation: exact at rank3, explicitly false at rank4.
I=(2,2,2);D=dmk.add((1,Q_expr(dmk.tensor('r12_03')(*I))),(-1,dmk.tensor('R12_03')(*I)))
assert not point(D,3);counter=point(D,4);assert counter
rec={'status':'PASS','Q0_flavour_commutator_on_all_six_raw_letters':36,'generic_CH3_identity':True,'CH4_negative_control':True,'independent_rank3_relation_zero':True,'rank4_relation_nonzero_exterior_coefficients':len(counter),'rank4_first_coefficient':[[hex(m),str(c)] for m,c in sorted(counter.items())[:1]],'method':'integer bosonic matrices + full independent exterior bitmask fermions; matrix multiplication, not trace path enumeration','seconds':time.monotonic()-t,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
Path(__file__).with_name('controls-receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(rec)
