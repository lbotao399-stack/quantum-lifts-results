from pathlib import Path
import sys,json,time,resource
from collections import defaultdict,deque
from fractions import Fraction as F
from itertools import product
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from fortuity.bmn import dmk
from fortuity.bmn.words import Q_expr,canon_word,add_term
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(300,300))
def action(A,i,j):
 out=defaultdict(F)
 for w,c in A.items():
  for a,tr in enumerate(w):
   for b,L in enumerate(tr):
    if L==j:K,s=i,1
    elif L==i+3:K,s=j+3,-1
    else:continue
    z,t=canon_word(tr[:b]+(K,)+tr[b+1:])
    if z:add_term(out,w[:a]+(t,)+w[a+1:],c*s*z)
 return dict(out)
def reduce(A,B):
 A={w:F(c) for w,c in A.items() if c}
 while A:
  w=min(A)
  if w not in B:return A
  c=A[w]
  for v,d in B[w].items():
   A[v]=A.get(v,0)-c*d
   if not A[v]:del A[v]
 return A
cases=[('r12_03',(2,2,2),10),('r12_11',(0,2),8),('r12_22',(0,0,2,2),27),('r14_13',(0,2,2,2),24),('r16_01',(2,),3),('r16_23',(0,0,2,2,2),42)]
t=time.monotonic();results=[];root=Path(__file__).resolve().parent
for name,I,expected in cases:
 r=dmk.tensor(name);R=dmk.tensor(dmk.R_OF_r[name])
 def diff(J):return dmk.add((1,Q_expr(r(*J))),(-1,R(*J)))
 D=diff(I);assert not action(D,0,1) and not action(D,1,2)
 B={};queue=deque([D])
 while queue:
  A=reduce(queue.popleft(),B)
  if not A:continue
  k=min(A);c=A[k];A={w:v/c for w,v in A.items()};B[k]=A
  for i,j in ((1,0),(2,1)):queue.append(action(A,i,j))
 assert len(B)==expected,(name,len(B),expected)
 for J in product(range(3),repeat=len(I)):assert not reduce(diff(J),B),(name,J)
 rec={'name':name,'orbit_rank_exact':len(B),'all_tensor_components_verified':3**len(I),'seconds':time.monotonic()-t,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};results.append(rec);print(rec,flush=True)
 (root/'orbit-receipt.json').write_text(json.dumps(results,indent=2)+'\n')
 # Saved sparse rows permit replay without any implicit representation claim.
 (root/(name+'-orbit.json')).write_text(json.dumps([[[str(c),w] for w,c in sorted(A.items())] for A in B.values()],separators=(',',':'))+'\n')
print('PASS_ALL_COMPONENTS_IN_EXACT_HIGHEST_ORBITS',flush=True)
for name,n in [('u2',2),('u3',3),('v2',2),('v3',3)]:
 for I in product(range(3),repeat=n):assert not Q_expr(getattr(dmk,name)(*I)),(name,I)
assert not dmk.relation_2_20()
O=dmk.o330();source=root.parent/'source/dmk_o330_hw.json'
assert O==dmk.load_rational_json(source)
rec={'status':'PASS_FACTORED_RATIONAL_SU3_Q0_CLOSURE','bare_terms':len(O),'all_prefactors_formally_Q0_closed':True,'relation_2_20_formally_zero':True,'exact_source_match':True,'six_generic_colour_highest_relations_required':'highest-receipt.json','all_components_covered':'orbit-receipt.json','seconds':time.monotonic()-t,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(root/'assembly-receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(rec,flush=True)
