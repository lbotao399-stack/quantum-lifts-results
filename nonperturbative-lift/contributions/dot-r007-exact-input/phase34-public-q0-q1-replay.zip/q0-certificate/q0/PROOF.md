# Exact finite-SU(3) closure of the public 6139-term R007

Input: davidsd/fortuity-ai 4256f207986029540060fb44dd494746828f65ce,
data/su3/dmk_o330_hw.json and code/fortuity/bmn/{dmk,words}.py.
This is the corrected dMK construction: traceless r/R tensors, five odd-prefactor Koszul signs, and the corrected r16 label. It is not the uncorrected printed polynomial.

1. For each of the six r-families used in O330, set D=Q0 r-R and take its highest flavour component. Expand D into completely generic traceless 3x3 matrices: each phi has eight independent commuting coordinates, each psi eight independent exterior coordinates. The (2,2) matrix entry is minus the other two diagonal entries. Trace path enumeration and supercommutative multiplication use integer coefficients after clearing rational denominators. ALL coefficients vanish, not evaluations at finitely many scalar points. The six formal differences have 8,43,9,7,337,11 trace terms, degrees5 or6. See highest-receipt.json.

2. Generate exact flavour lowering orbits directly in formal graded trace coordinates. Sparse rational elimination gives orbit dimensions10,8,27,24,3,42. Every one of the 444 tensor components of D reduces to zero in its corresponding orbit span. The saved sparse orbit rows and deterministic generation replay remove any need to assume irreducibility or extrapolate from sampled tensor components. Finite-colour substitution commutes with flavour change; all these orbit vectors therefore vanish as generic matrix polynomials. Independently the raw noncommutative [Eij,Q0] vanishes on each of the six letters.

3. The u2,u3,v2,v3 prefactors are Q0-closed as FORMAL graded trace polynomials for all their indices. The projected relation of relations sum c_a f_a R_a is identically zero formally. The rebuilt sum with the odd-prefactor signs equals every coefficient of the given 6139-term JSON. The graded derivation identity then gives Q0 O330=0 exactly over Q at N=3. There is no large numeric rank step in this proof and no assumption about EOM, translation quotient, a physical Gram matrix or higher Qn.

Independent controls: a different evaluator multiplies numeric integer bosonic matrices and full exterior bitmask fermion matrices. The r12_03 relation is zero at N=3 but has15 nonzero coefficients at N=4 (first coefficient -3604364). The generic Cayley-Hamilton trace identity tr(X^4)=tr(X^2)^2/2 passes atN3 and fails atN4; a simple trace-square is explicitly nonzero. These controls catch rank-independent cancellation and the trivial-zero evaluator failure. They are exact deterministic checks, not randomized confidence estimates.

Replay from the certificate root:
python3 -B q0/highest_checks.py
python3 -B q0/orbit_certificate.py
python3 -B q0/independent_controls.py

Dependency: Python standard library plus SymPy for the public traceless projector; tested SymPy 1.14.0. Limits: each primary consumer4GiB and300CPU seconds; controls120CPU seconds. Observed highest test4.05s/83048KiB, orbit+assembly about4.2s/60128KiB, controls0.02s. Receipts are the measured authority; reruns may vary.

This certifies classical Q0 closure only. Non-exactness, a polynomial O1, all-order formal survival and physical nonperturbative claims are separate tasks.
