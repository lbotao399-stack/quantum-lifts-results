import sys,itertools as it
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
import algebra as v
sys.path.insert(0,str(Path(__file__).resolve().parent/'public/so8-protected'))
from q2d_exact import triple_rule,jet_terms
@lru_cache(None)
def color(a,b,c,d,e):return sum(v.E(a,p,d)*v.E(b,p,q)*v.E(c,q,e) for p,q in it.product(range(3),repeat=2))
@lru_cache(None)
def qt(x,y,z):
 (L,a),(M,b),(N,c)=x,y,z;o=defaultdict(F)
 for co,S,T in triple_rule(L[2],M[2],N[2]):
  for cf,U,V in jet_terms((L[:2],M[:2],N[:2])):
   for d,e in it.product(range(3),repeat=2):v.add(o,((U+(S,),d),(V+(T,),e)),-F(co*cf*color(a,b,c,d,e),6))
 return v.clean(o)
def q2(P):
 out=defaultdict(F)
 for w,c in P.items():
  for tri in it.combinations(range(len(w)),3):
   rest=[i for i in range(len(w)) if i not in tri]
   for mid in tri:
    a,b=[i for i in tri if i!=mid];perm=[a,mid,b]+rest;s=(-1)**sum(v.odd(w[perm[i]])*v.odd(w[perm[j]]) for i in range(len(w)) for j in range(i+1,len(w)) if perm[i]>perm[j])
    for pair,cf in qt(w[a],w[mid],w[b]).items():v.add(out,pair+tuple(w[i] for i in rest),c*s*cf)
 return v.clean(out)
