import itertools as it
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
from math import factorial as fac,comb
import algebra as v
@lru_cache(None)
def theta_sat(sets):
 n=len(sets)-1
 if sum(map(len,sets))!=3*n:return 0
 # Move the odd input fields past subsequent theta factors; Q passes all input theta.
 lhs=(-1)**(sum(map(len,sets))+sum(((len(sets[i])+1)%2)*len(sets[j]) for i in range(n+1) for j in range(i+1,n+1)))
 out=0;target=[(i,a) for i,S in enumerate(sets) for a in S]
 for ch in it.product((0,1),repeat=3*n):
  p=[(edge+ch[3*edge+a],a) for edge in range(n) for a in range(3)]
  if len(set(p))!=len(p) or sorted(p)!=target:continue
  out+=lhs*(-1)**(sum(ch)+sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p))))
 return out
@lru_cache(None)
def chain(colors,d,e):
 n=len(colors)-1
 return sum(v.E(colors[0],d,rr[0])*__import__('functools').reduce(lambda a,j:a*v.E(colors[j],rr[j-1],rr[j]),range(1,n),1)*v.E(colors[-1],rr[-1],e) for rr in it.product(range(3),repeat=n))
@lru_cache(None)
def q3quad(xs):
 out=defaultdict(F);n=3;pref=F(-1,216)
 assert all(x[0][:2]==(0,0) for x in xs)
 for perm in it.permutations(range(4)):
  S=tuple(xs[i][0][2] for i in perm);co=theta_sat(S)
  if not co:continue
  sg=(-1)**sum(v.odd(xs[perm[i]])*v.odd(xs[perm[j]]) for i in range(4) for j in range(i+1,4) if perm[i]>perm[j]);cs=tuple(xs[i][1] for i in perm)
  for d,e in it.product(range(3),repeat=2):
   color=chain(cs,d,e)
   for k in range(4):
    a,b=3-k,k;cf=(-1)**k*comb(3,k)*fac(a)*fac(b)*fac(b)*fac(a)
    v.add(out,(((a,b,()),d),((b,a,()),e)),pref*co*sg*color*cf)
 return v.clean(out)
def q3(P):
 o=defaultdict(F);potential=0
 for w,c in P.items():
  for tri in it.combinations(range(len(w)),4):
   if sum(len(w[i][0][2]) for i in tri)!=9:continue
   potential+=1;assert all(w[i][0][:2]==(0,0) for i in tri)
   rest=[i for i in range(len(w)) if i not in tri];perm=list(tri)+rest
   sg=(-1)**sum(v.odd(w[perm[i]])*v.odd(w[perm[j]]) for i in range(len(w)) for j in range(i+1,len(w)) if perm[i]>perm[j])
   for z,a in q3quad(tuple(w[i] for i in tri)).items():v.add(o,z+tuple(w[i] for i in rest),c*sg*a)
 return v.clean(o),potential
