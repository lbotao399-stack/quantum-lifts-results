"""Exact raw derivative triangle moments, LLC eqs 2.3--2.7.
No claim of a complete physical Q1/Q2 component implementation.
"""
from fractions import Fraction as F
from math import factorial as fac,comb
from itertools import product
from functools import lru_cache
import json
from pathlib import Path
@lru_cache(None)
def moment(a,b,c,d):
 # integral_triangle (1-r)^a r^b s^c (1-s)^d dr ds
 return sum((F((-1)**(i+j)*comb(a,i)*comb(d,j)*fac(b+i)*fac(c+j),fac(b+i+c+j+2)) for i in range(a+1) for j in range(d+1)),F(0))
@lru_cache(None)
def triangle(P,Q):
 # Raw jets P=(p+,p-),Q=(q+,q-). Output increment (u+,u-;v+,v-).
 out={}
 for u in product(*(range(x+1) for x in P)):
  for v in product(*(range(x+1) for x in Q)):
   c=2*moment(sum(u),sum(v),sum(P)-sum(u),sum(Q)-sum(v))
   c*=comb(P[0],u[0])*comb(P[1],u[1])*comb(Q[0],v[0])*comb(Q[1],v[1])
   key=(u[0]+v[0],u[1]+v[1],P[0]+Q[0]-u[0]-v[0],P[1]+Q[1]-u[1]-v[1])
   out[key]=out.get(key,F(0))+c
 return {k:c for k,c in out.items() if c}
def add(a,b):
 o=a.copy()
 for k,v in b.items():o[k]=o.get(k,F(0))+v
 return {k:v for k,v in o.items() if v}
def translate(a,axis):
 o={}
 for k,c in a.items():
  for idx in (axis,axis+2):
   z=list(k);z[idx]+=1;z=tuple(z);o[z]=o.get(z,F(0))+c
 return o
if __name__=='__main__':
 checks=0
 for p,q in product(product(range(3),repeat=2),repeat=2):
  if sum(p)+sum(q)>3:continue
  for axis in (0,1):
   pp=list(p);pp[axis]+=1;qq=list(q);qq[axis]+=1
   assert add(triangle(tuple(pp),q),triangle(p,tuple(qq)))==translate(triangle(p,q),axis);checks+=1
 assert triangle((0,0),(0,0))=={(0,0,0,0):F(1)}
 assert triangle((1,0),(0,0))=={(1,0,0,0):F(2,3),(0,0,1,0):F(1,3)}
 # n=2 no-input moment: r1*r2*r4 over [0,1]^2 times triangle(r3,r4)
 n2=F(1,2)*F(1,2)*F(1,6);assert n2==F(1,24)
 result={'scope':'scalar raw-jet kernel only; theta, colour, physical normalization not certified','translation_checks':checks,'n1_integral':'1/2','n2_no_input_integral':str(n2),'one_derivative_normalized_moments':{str(k):str(v) for k,v in triangle((1,0),(0,0)).items()}}
 Path(__file__).with_name('jet-kernel-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
