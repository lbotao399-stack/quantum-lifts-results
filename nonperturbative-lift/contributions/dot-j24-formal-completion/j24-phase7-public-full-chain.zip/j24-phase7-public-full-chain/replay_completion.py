"""Standard-library-only exact A3 Taylor Q0 replay, no public/private implementation imports."""
import itertools as it,json,gzip,time,resource
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
r=Path(__file__).resolve().parent;t=time.monotonic();resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
odd=lambda x:(len(x[0][2])+1)%2
def add(o,w,c):
 a=[x for x in w if odd(x)]
 if len(a)!=len(set(a)):return
 s=(-1)**sum(a[i]>a[j] for i in range(len(a)) for j in range(i+1,len(a)));o[tuple(sorted(w))]+=c*s
@lru_cache(None)
def letter(x):
 (ap,am,S),a=x;o=defaultdict(F)
 for bp in range(ap+1):
  for bm in range(am+1):
   for mask in range(1<<len(S)):
    U=tuple(x for k,x in enumerate(S) if mask>>k&1);V=tuple(x for x in S if x not in U)
    if not U and bp+bm==0 or not V and ap+am-bp-bm==0:continue
    sign=(-1)**(len(S)+((len(U)+1)%2)*len(V)+sum(u>v for u in U for v in V))
    for b,c in it.permutations(range(3),2):
     if len({a,b,c})<3:continue
     eps=(-1)**((a>b)+(a>c)+(b>c));add(o,(((bp,bm,U),b),((ap-bp,am-bm,V),c)),F(sign*eps,2))
 return {w:c for w,c in o.items() if c}
def q0(P):
 o=defaultdict(F)
 for w,c in P.items():
  prefix=1
  for j,x in enumerate(w):
   for z,a in letter(x).items():add(o,w[:j]+z+w[j+1:],c*a*prefix)
   if odd(x):prefix=-prefix
 return {w:c for w,c in o.items() if c}
def read(n):return {tuple(((a,b,tuple(S)),c) for ((a,b,S),c) in w):F(co) for w,co in json.load(gzip.open(r/n,'rt'))}

data=json.load(gzip.open(r/'completion-reduced.json.gz','rt'))
def unpack(P):return {tuple(((a,b,tuple(S)),c) for ((a,b,S),c) in w):F(co) for w,co in P}
orders=[]
for j,(P,R) in enumerate(zip(data['O'],data['R'])):
 P,R=unpack(P),unpack(R);assert q0(P)=={w:-c for w,c in R.items()};orders.append({'order':j,'O_terms':len(P),'R_terms':len(R),'boundary_equation':True});print('order',j,'PASS',flush=True)
(r/'completion-independent-replay.json').write_text(json.dumps({'field':'Q','imports':'standard library only','orders':orders,'scope':'independent Q0 equations for supplied source-traced RHS; Qn construction controls stored separately','wall_seconds':time.monotonic()-t,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2)+'\n')
