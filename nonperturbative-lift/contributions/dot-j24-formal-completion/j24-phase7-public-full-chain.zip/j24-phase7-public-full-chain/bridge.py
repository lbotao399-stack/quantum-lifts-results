import sys,json,gzip,itertools as it
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r));import algebra as v
# Transport the independently certified classical complex, including the b sign.
checks=0
for i,a in it.product(range(3),repeat=2):
 gamma=(((0,0,(i,)),a),);assert not v.q0({gamma:F(1)});checks+=1
 lhs=v.q0({(((0,0,tuple(k for k in range(3) if k!=i)),a),):F((-1)**i)});rhs=defaultdict(F);j,k=(i+1)%3,(i+2)%3
 for b,c in it.permutations(range(3),2):v.add(rhs,(((0,0,(j,)),b),((0,0,(k,)),c)),v.E(a,b,c))
 assert lhs==v.clean(rhs);checks+=1
for a in range(3):
 lhs=v.q0({(((0,0,(0,1,2)),a),):F(-1)});rhs=defaultdict(F)
 for i in range(3):
  for b,c in it.permutations(range(3),2):v.add(rhs,(((0,0,(i,)),b),((0,0,tuple(k for k in range(3) if k!=i)),c)),v.E(a,b,c)*(-1)**i)
 assert lhs==v.clean(rhs);checks+=1

d=json.load(gzip.open(r/'completion-reduced.json.gz','rt'));c=json.loads((r/'o0_classical_certificate.json').read_text());T=defaultdict(F)
# Certificate uses monomials (boson exponents, fermion bitmask).
for key,co in c['O0']:
 e,m=c['target_basis'][key];w=[];cf=F(co)
 for j,n in enumerate(e):
  if j<9:L=(0,0,(j//3,));color=j%3
  else:L=(0,0,(0,1,2));color=j-9;cf*=(-1)**n
  w.extend([(L,color)]*n)
 for j in range(9):
  if m>>j&1:
   i=j//3;w.append(((0,0,tuple(k for k in range(3) if k!=i)),j%3));cf*=(-1)**i
 v.add(T,tuple(w),cf)
P={tuple(((a,b,tuple(S)),col) for ((a,b,S),col) in w):F(co) for w,co in d['O'][0]}
assert v.clean(T)==P
(r/'bridge.json').write_text(json.dumps({'letter_checks':checks,'O0_full_match':True,'dual_pairing':c['dual_pairing_O0']},indent=2)+'\n');print('bridge PASS',checks)
