"""Verify immutable allowlist/hash set, then replay in an isolated temporary copy."""
import hashlib,sys,tempfile,shutil,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent
allow=(r/'ALLOWLIST.txt').read_text().splitlines();actual=sorted(str(p.relative_to(r)) for p in r.rglob('*') if p.is_file())
assert actual==allow, 'Unexpected/missing archive files'
for line in (r/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
with tempfile.TemporaryDirectory(prefix='j24-replay-') as d:
 b=Path(d)/'bundle';shutil.copytree(r,b)
 for s in ['bridge.py','verify_o0_dual.py','replay_completion.py','q3_berezin_control.py','endpoint_degree4_control.py','replay_kernels.py']:
  z=subprocess.run([sys.executable,'-I','-B',str(b/s)],capture_output=True,text=True,timeout=300)
  if z.returncode:print(z.stdout,z.stderr);raise SystemExit(z.returncode)
  print(s,'PASS',flush=True)
print('SELF TEST PASS; original archive unchanged')
