# Public j24 finite formal completion: exact replay

This archive certifies a finite closed representative O(u)=sum(r=0..4)u^r O_r in the declared relative Taylor-superfield complex over Q[[u]]. It does not establish a nonperturbative lift, physical instanton matrix, or unconditional equivalence to strict physical SYM composite operators.

Run with Python 3.11 or later, standard library only, on Linux:

    python3 -I -B replay_kernels.py
    python3 -I -B replay_completion.py
    python3 -I -B bridge.py
    python3 -I -B verify_o0_dual.py
    python3 -I -B q3_berezin_control.py
    python3 -I -B endpoint_degree4_control.py

No network, symbolic algebra package, private import or original workspace is needed. Run sequentially. Main kernel replay measured 51.57 s and 683320 KiB peak RSS on a 4 CPU /16 GiB cgroup. It enforces a 5 GiB address-space and240 CPU-second limit. The independent Q0 replay has a3 GiB/120-second bound. Other controls are small. Runtime receipts are included; timings are machine-dependent.

## Inputs versus reconstructed operators

* `completion-reduced.json.gz` supplies exact coefficients O0..O4 and archived RHS. The solve that found O1..O3 and the homogeneous branch choice are NOT reproduced here. Replaying the resulting identity is independent of how those input vectors were found. O term counts117,29799,39651,8271,105.
* `replay_kernels.py` does NOT assume the archived RHS: it reconstructs each Q1/Q2/Q3 term, compares exact rational polynomials with RHS, and checks Q0O_r=-R_r.
* Q0 is from pinned public letter rules in that replay. `replay_completion.py` implements Q0 separately from the Taylor expansion of Q(Psi)=Psi², with no public implementation imports.
* Q1: public theta rule plus newly written exact triangle moments and Cartesian colour/Koszul implementation (`jet_kernel.py`, `algebra.py`).
* Q2: public theta rule and public input-jet endpoint moments, adapted by prefix extraction to avoid unused numeric dependencies; newly written Cartesian colour/Koszul action. Its coefficient -1/6 is source-derived in the stated fan convention, not fitted in this archive. `endpoint_degree4_control.py` independently integrates all210 needed endpoint moments with exact rational quadrature. This is a mixed independently reconstructed/public-input implementation, NOT a wholly independent Q2 derivation.
* Q3: newly written saturated theta/path-colour fan, restricted to no-input-jet quadruples. All actual Q3O1 inputs satisfy that restriction. Coefficient -1/216 includes all24 input permutations. `q3_berezin_control.py` independently evaluates left Berezin derivatives on all20/84/220 saturated theta tuples for n1/2/3. Full arbitrary-jet Q3 is not implemented.
* Q3O0 and Q4O0 vanish by input theta saturation, checked on actual support. No arbitrary Q4 kernel is supplied. Every later direct term vanishes because its total theta degree is12-3r<0 for r>=5.

The public source is Li–Liu–Chang, https://arxiv.org/pdf/2611.24160v1 (A.2–A.4,2.3–2.8,8.5,8.8). Pinned supplementary repository commit c28f7b67c0cfa533ee1039e909a5ee2a82404591, supplement three-term O4:
https://github.com/lbotao399-stack/quantum-lifts-results/blob/c28f7b67c0cfa533ee1039e909a5ee2a82404591/supplement/supplement.tex#L2204
Exact per-file public links, original hashes and extraction boundaries are in `public-provenance.json`. Public q2bmn's historical docstring describes a nilpotence calibration; the normalization used here is independently fixed from the published fan coefficient. The public subset is explicitly identified, not claimed as newly authored code.

## Conventions and nonexactness

Letters ((a,b,S),colour) mean divided-power jets of Psi_S, colour0..2, C_abc=epsilon_abc; parity=(|S|+1)mod2. Empty theta with zero jets is excluded (relative complex). No total-derivative quotient is taken. Bosonic equations are those encoded in this letter complex; no additional EOM quotient is asserted.

Q_LLC/i = sum u^n Q_n,reduced with u=i hbar/(2*32*pi²). Equivalently the earlier working physical scaling divides Q_n and O_n by8^n. Fundamental traces use Tr(TaTb)=delta/2, Tr(TaTbTc)=i epsilon/4. The supplement O0 equals(i/16) times this reduced O0.

`bridge.py` verifies all21 letter equations and transports the full classical O0 into the supplied Taylor O0. The independent classical dual replay checks all2808 raw incoming columns and ell(O0)=-30. This dual and its ambient target basis are supplied rational data, not a recomputed rank solve. Projection pi0 to zero jets obeys pi0 Q=Q0 pi0 since positive-loop Qn adds(n,n) jets. Consequently ell*pi0 pairs with the completed class as -30. If f(u)O=QX for a nonzero formal series f, applying ell*pi0 gives -30f=0, impossible. Thus closure, nonexactness, and absence of formal-parameter torsion follow separately, in the declared fixed basis. This does not transfer automatically through singular coupling-dependent basis changes or to nonperturbative maps.

`ALLOWLIST.txt` and `SHA256SUMS` delimit the archive. It contains only public-source excerpts, newly generated code, rational coefficients and receipts; no private manuscript, credential, personal data or transfer helper. This is for review, with no repository push.
