#!/usr/bin/env python3
"""Separate replay of saved rational dual; no import of producer or private code.
This verifies a classical boundary test, not missing higher-loop primitives.
"""
import itertools as it,json
from fractions import Fraction as F
from pathlib import Path
p=Path(__file__).with_name('o0_classical_certificate.json')
c=json.loads(p.read_text());basis=[(tuple(e),m) for e,m in c['target_basis']]
assert len(set(basis))==len(basis)==9000
functional={basis[i]:F(v) for i,v in c['dual']}
# Canonical variable word: bosons 0..11, fermions 12..20.
def canonical(word):
 odd=[x for x in word if x>=12]
 if len(set(odd))<len(odd):return None,0
 s=(-1)**sum(odd[i]>odd[j] for i in range(len(odd)) for j in range(i+1,len(odd)))
 e=tuple(word.count(i) for i in range(12));m=sum(1<<(x-12) for x in odd)
 return (e,m),s

def word(x):
 e,m=x
 return [i for i,k in enumerate(e) for _ in range(k)]+[12+i for i in range(9) if m>>i&1]

def deriv(w):
 out={};sign=1
 for pos,x in enumerate(w):
  terms=[]
  if 9<=x<12:
   a=x-9;b,d=(a+1)%3,(a+2)%3
   for i in range(3):terms.extend([(1,[3*i+b,12+3*i+d]),(-1,[3*i+d,12+3*i+b])])
  if x>=12:
   i,a=divmod(x-12,3);j,k=(i+1)%3,(i+2)%3;b,d=(a+1)%3,(a+2)%3
   terms=[(1,[3*j+b,3*k+d]),(-1,[3*j+d,3*k+b])]
  for co,rep in terms:
   key,s=canonical(w[:pos]+rep+w[pos+1:])
   if s:out[key]=out.get(key,0)+sign*co*s
  if x>=12:sign=-sign
 return {x:v for x,v in out.items() if v}
# Enumerate source using stars and bars from scalar/b degrees after each odd mask.
def splits(n):
 for a in range(n+1):
  for b in range(n-a+1):yield (a,b,n-a-b)
sources=[]
for m in range(512):
 counts=[((m>>(3*i))&7).bit_count() for i in range(3)]
 for nb in range(5):
  ns=[4-nb-sum(counts)+counts[i] for i in range(3)]
  if min(ns)<0 or sum(ns)+sum(counts)+nb!=6:continue
  for e in it.product(*(list(splits(n)) for n in ns+[nb])):sources.append((sum(e,()),m))
assert len(sources)==2808
columns=[deriv(word(x)) for x in sources]
basis_set=set(basis)
for col in columns:
 assert all(k in basis_set for k in col)
 assert sum(v*functional.get(k,0) for k,v in col.items())==0
O={basis[i]:v for i,v in c['O0']};variation={}
for x,v in O.items():
 for y,a in deriv(word(x)).items():variation[y]=variation.get(y,0)+v*a
assert all(v==0 for v in variation.values())
pairing=sum(v*functional.get(x,0) for x,v in O.items())
assert pairing==F(c['dual_pairing_O0'])==-30
# An actual nonzero boundary gives a positive primitive control.
i=next(i for i,col in enumerate(columns) if col)
assert sum(v*functional.get(k,0) for k,v in columns[i].items())==0
result={'status':'PASS','exact_field':'Q','classical_O0_closed':True,
'classical_O0_not_boundary':True,'dual_pairing':str(pairing),
'full_source_columns_replayed':len(columns),'primitive_control_source_index':i,
'primitive_control_boundary_terms':len(columns[i]),'quantum_completion_verified':False}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,sort_keys=True))
