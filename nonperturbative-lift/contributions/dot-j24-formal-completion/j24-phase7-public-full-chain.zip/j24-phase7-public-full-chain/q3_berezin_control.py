"""Independent saturated theta coefficient from A4 left derivatives, not delta chains."""
import json,itertools as it
from pathlib import Path
r=Path(__file__).resolve().parent
import sys
sys.path.insert(0,str(r))
from q3_action import theta_sat as theta
def direct(S):
 pref=[];co=1;remaining=list(range(len(S)))
 for i in reversed(range(len(S))):
  complement=tuple(x for x in range(3) if x not in S[i]);parity=(len(S[i])+1)%2
  co*=(-1)**(len(S[i])+sum(a>b for a in S[i] for b in complement))
  co*=(-1)**(parity*(len(pref)+sum((len(S[j])+1)%2 for j in remaining if j<i)))
  pref=list(complement)+pref;remaining.remove(i)
 if sorted(pref)!=[0,1,2]:return 0
 return co*(-1)**sum(pref[i]>pref[j] for i in range(3) for j in range(i+1,3))
sets=[tuple(i for i in range(3) if m>>i&1) for m in range(8)];rows=[]
for n in (1,2,3):
 count=0;bad=[]
 for S in it.product(sets,repeat=n+1):
  if sum(map(len,S))!=3*n:continue
  count+=1
  if direct(S)!=theta(S):bad.append((S,direct(S),theta(S)))
 rows.append({'n':n,'all_saturated_theta_tuples':count,'mismatch_count':len(bad),'first_mismatch':bad[:1]})
(r/'q3-berezin-control.json').write_text(json.dumps({'source':'LLC A4 converted via A2 to Psi coefficient derivatives; rightmost derivative acts first, passing all previously generated odd theta factors','checks':rows},indent=2)+'\n');print(rows)
