"""Exact end-to-end RHS reconstruction on supplied representative support."""
import sys,json,gzip,time,resource
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r))
import algebra as v
from q2_action import q2
from q3_action import q3
resource.setrlimit(resource.RLIMIT_AS,(5*1024**3,5*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(240,240));t=time.monotonic()
def unpack(P):return {tuple(((a,b,tuple(S)),c) for ((a,b,S),c) in w):F(co) for w,co in P}
def plus(*args):
 o=defaultdict(F)
 for P in args:
  for w,c in P.items():o[w]+=c
 return v.clean(o)
d=json.load(gzip.open(r/'completion-reduced.json.gz','rt'));O=list(map(unpack,d['O']));R=list(map(unpack,d['R']));receipt=[]
assert not v.q0(O[0])
for n in range(1,5):
 parts=[v.q1(O[n-1])]
 if n>=2:parts.append(q2(O[n-2]))
 if n==3:assert all(sum(sorted([len(x[0][2]) for x in w],reverse=True)[:4])<9 for w in O[0])
 if n==4:
  parts.append(q3(O[1])[0]);assert all(sum(sorted([len(x[0][2]) for x in w],reverse=True)[:5])<12 for w in O[0])
 X=plus(*parts);assert X==R[n];assert not plus(v.q0(O[n]),X)
 receipt.append({'order':n,'part_terms':list(map(len,parts)),'R_terms':len(X),'R_matches':True,'equation':True});print(receipt[-1],flush=True)
for j,P in enumerate(O):assert all(sum(len(x[0][2]) for x in w)==12-3*j for w in P)
# All order>=5 terms have total theta degree12-3*order<0.
(r/'kernel-replay.json').write_text(json.dumps({'field':'Q','orders':receipt,'tail_zero_by_theta':True,'wall_seconds':time.monotonic()-t,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2)+'\n')
