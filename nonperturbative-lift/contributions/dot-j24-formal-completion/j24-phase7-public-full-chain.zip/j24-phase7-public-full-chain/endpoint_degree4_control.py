import sys,itertools as it,json,time
from pathlib import Path
from fractions import Fraction as F
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r))
from q2_action import qt
from q2d_exact import moment
# Independent rational seven-node Newton-Cotes integration on unit cube; r3=u,r4=(1-u)v.
# All needed moments have exponent sum<=4; resulting polynomial degree<=6 per variable,
# so the degree-seven exact quadrature proves these integrals, without floating point.
nodes=[F(i,6) for i in range(7)];weights=[F(x,840) for x in (41,216,27,272,27,216,41)];samples=[]
for i,j,k,l in it.product(range(7),repeat=4):
 a,b,u,v=[nodes[x] for x in (i,j,k,l)];d=(1-u)*v
 A=(1-a+a*(1-u)*(1-b),a*b*(1-u),a*u);B=(d*(1-b),d*b,1-d)
 w=24*weights[i]*weights[j]*weights[k]*weights[l]*a*b*v*(1-u)**2;samples.append((A+B,w))
exps=[(0,)*6]
for deg in (1,2,3,4):
 for inds in it.combinations_with_replacement(range(6),deg):exps.append(tuple(inds.count(i) for i in range(6)))
for e in exps:
 val=F(0)
 for x,w in samples:
  for a,n in zip(x,e):w*=a**n
  val+=w
 assert val==moment(e),(e,val,moment(e))
(r/'endpoint-degree4-control.json').write_text(json.dumps({'field':'Q','independent_exact_quadrature_moments':len(exps),'covers':'all total input derivative degree<=4, hence every Q2 triple in actual O2 support','first_moments':['1/2','1/3','1/6','1/6','1/3','1/2'],'method':'seven-node closed Newton-Cotes degree7 exact; transformed integrands degree<=6 per variable'},indent=2)+'\n');print('PASS',len(exps))
