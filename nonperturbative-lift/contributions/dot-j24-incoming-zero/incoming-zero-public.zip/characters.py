"""Full component characters; no invariant-basis or rank input."""
from itertools import combinations,product
from collections import defaultdict

def count(k,maxY):
 theta=4-k
 letters=[(a,b,S) for a in range(k+2) for b in range(k+1) if a+b<=2*k for n in range(min(3,3*theta)+1) for S in combinations(range(3),n) if n+a+b>0]
 D={(0,0,0,0,0,0,0):1}
 for (a,b,S),col in product(letters,(-1,0,1)):
  wt=tuple(int(i in S) for i in range(3));odd=(len(S)+1)%2;N=defaultdict(int)
  for (Y,x,y,z,u,v,c),value in D.items():
   cap=min(maxY-Y,(k+1-u)//a if a else maxY,(k-v)//b if b else maxY,(2*k-u-v)//(a+b) if a+b else maxY)
   for j,W in enumerate(wt):
    if W:cap=min(cap,[theta+2-x,theta+1-y,theta-z][j])
   if S:cap=min(cap,(3*theta-x-y-z)//len(S))
   if odd:cap=min(cap,1)
   for n in range(cap+1):N[Y+n,x+n*wt[0],y+n*wt[1],z+n*wt[2],u+n*a,v+n*b,c+n*col]+=value
  D=N
 roots=[(1,-1,0),(0,1,-1),(1,0,-1)];out={}
 for Y in range(maxY+1):
  value=0
  for mask in range(8):
   w=tuple(theta+sum(roots[j][i] for j in range(3) if mask>>j&1) for i in range(3));sgn=(-1)**mask.bit_count()
   for a,b,s in [(k,k,1),(k+1,k-1,-1)]:value+=sgn*s*(D.get((Y,*w,a,b,0),0)-D.get((Y,*w,a,b,1),0))
  out[Y]=value
 return out
