"""Candidate Taylor bridge; diagnostics never certify failing extension."""
import sys,json,itertools as it
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
from math import factorial as fac
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r));from jet_kernel import triangle
v=r/'public/vendor';sys.path.insert(0,str(v))
from fortuity.full.letters import Q_letter
from fortuity.full.q1 import pair_rule
from functools import lru_cache
odd=lambda x:(len(x[0][2])+1)%2
E=lambda a,b,c:0 if len({a,b,c})<3 else (-1)**((a>b)+(a>c)+(b>c))
def add(out,w,c):
 o=[x for x in w if odd(x)]
 if len(set(o))!=len(o):return
 s=(-1)**sum(o[i]>o[j] for i in range(len(o)) for j in range(i+1,len(o)));w=tuple(sorted(w));out[w]+=s*c
clean=lambda p:{w:c for w,c in p.items() if c}
@lru_cache(None)
def ql(x):
 L,a=x;o=defaultdict(F)
 for co,U,V in Q_letter(L):
  for b,c in it.product(range(3),repeat=2):add(o,((U,b),(V,c)),F(co*E(a,b,c),2))
 return clean(o)
def public_q0(P):
 o=defaultdict(F)
 for w,c in P.items():
  for i,x in enumerate(w):
   s=(-1)**sum(map(odd,w[:i]))
   for z,d in ql(x).items():add(o,w[:i]+z+w[i+1:],c*d*s)
 return clean(o)
@lru_cache(None)
def qp(x,y):
 (a,b,S),A=x;(c,d,T),B=y;o=defaultdict(F)
 for co,D,G in pair_rule(S,T):
  for (u,v,w,z),m in triangle((a,b),(c,d)).items():
   U=(D[0]+u,D[1]+v,D[2]);V=(G[0]+w,G[1]+z,G[2])
   f=F(fac(U[0])*fac(U[1])*fac(V[0])*fac(V[1]),fac(a)*fac(b)*fac(c)*fac(d))
   for C,H,I in it.product(range(3),repeat=3):add(o,((U,H),(V,I)),co*m*f*E(A,C,H)*E(B,C,I))
 return clean(o)
def q1(P):
 o=defaultdict(F)
 for w,c in P.items():
  for i,j in it.combinations(range(len(w)),2):
   s=(-1)**(odd(w[i])*sum(map(odd,w[:i]))+odd(w[j])*sum(odd(w[k]) for k in range(j) if k!=i))
   rest=w[:i]+w[i+1:j]+w[j+1:]
   for z,d in qp(w[i],w[j]).items():add(o,z+rest,c*d*s)
 return clean(o)
def anti(P):
 o=defaultdict(F,q0(q1(P)))
 for w,c in q1(q0(P)).items():o[w]+=c
 return clean(o)

from algebra import q0
