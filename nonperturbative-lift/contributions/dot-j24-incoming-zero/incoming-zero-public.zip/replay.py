"""Portable incoming-zero certificate. Standard library only; no network."""
import sys,json,gzip,time,resource,hashlib
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
r=Path(__file__).resolve().parent;t=time.monotonic();resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(300,300))
from algebra import q0,add,clean,singlet_checks,act
from higher import q1
from q2_action import q2
from characters import count
p=2147483647
word=lambda w:tuple(((a,b,tuple(S)),c) for ((a,b,S),c) in w)
unpack=lambda P:{word(w):F(c) for w,c in P}
def mod(c):
 c=F(c);assert c.denominator%p;return c.numerator%p*pow(c.denominator,-1,p)%p
def det(M):
 A=[row[:] for row in M];d=1
 for i in range(len(A)):
  j=next(j for j in range(i,len(A)) if A[j][i])
  if i!=j:A[i],A[j]=A[j],A[i];d=-d
  a=A[i][i];d=d*a%p;iv=pow(a,-1,p)
  for j in range(i+1,len(A)):
   c=A[j][i]*iv%p
   if c:
    for k in range(i+1,len(A)):A[j][k]=(A[j][k]-c*A[i][k])%p
 return d%p
def rank(Ps):
 piv={}
 for P in Ps:
  x={w:mod(c) for w,c in P.items() if mod(c)}
  while x:
   w=min(x)
   if w not in piv:break
   c=x[w]
   for z,a in piv[w].items():
    b=(x.get(z,0)-c*a)%p
    if b:x[z]=b
    else:x.pop(z,None)
  if x:
   w=min(x);iv=pow(x[w],-1,p);piv[w]={z:a*iv%p for z,a in x.items()}
 return len(piv)
def zero(*Ps):
 d=defaultdict(F)
 for P in Ps:
  for w,c in P.items():d[w]+=c
 return not any(d.values())
def deriv(P,axis):
 out=defaultdict(F)
 for w,c in P.items():
  for j,((a,b,S),col) in enumerate(w):
   L=(a+1,b,S) if axis==0 else (a,b+1,S)
   add(out,w[:j]+((L,col),)+w[j+1:],c*(a+1 if axis==0 else b+1))
 return clean(out)
chars={k:count(k,6-k) for k in range(5)}
assert [chars[k][6-k] for k in range(5)]==[4,55,86,13,0]
assert chars[2][3]==8
print('characters PASS',flush=True)
letters=set();ranks={};minors=[]
for m in json.loads((r/'matrices.json').read_text()):
 rows=list(map(word,m['rows']));matrix=[];seen=[];k=m['k'];Y=m['source_Y']
 with gzip.open(r/(m['name']+'.jsonl.gz'),'rt') as f:
  for line in f:
   obj=json.loads(line);seen.append(obj['index']);P=unpack(obj['polynomial'])
   assert all(len(w)==Y and tuple(sum(x[0][i] for x in w) for i in (0,1))==(k,k) and tuple(sum(i in x[0][2] for x in w) for i in range(3))==(4-k,)*3 for w in P)
   assert all(singlet_checks(P));Q=q0(P);assert all(singlet_checks(Q));letters.update(x for w in P for x in w)
   matrix.append([mod(Q.get(w,0)) for w in rows])
 assert seen==m['columns'] and len(matrix)==m['rank']==len(rows)
 d=det(matrix);assert d;ranks[k,Y]=len(rows);minors.append({'map':m['name'],'rank_lower_Q':len(rows),'determinant':d});print(m['name'],'PASS',flush=True)
full=json.load(gzip.open(r/'k2-incoming-full.json.gz','rt'));H=list(map(unpack,full['basis']));assert len(H)==8 and rank(H)==8;images=[]
for P in H:
 assert all(singlet_checks(P));assert all(len(w)==3 and tuple(sum(x[0][i] for x in w) for i in (0,1))==(2,2) and tuple(sum(i in x[0][2] for x in w) for i in range(3))==(2,2,2) for w in P)
 images.append(q0(P));letters.update(x for w in P for x in w)
assert rank(images)==7 and len(full['kernel_coordinates'])==1
for h in full['kernel_coordinates']:
 assert any(F(c) for c in h.values());assert zero(*[{w:F(c)*a for w,a in images[int(j)].items()} for j,c in h.items()])
ranks[2,3]=7;ranks[0,5]=0
assert [ranks.get((k,5-k),0)+ranks.get((k,6-k),0) for k in (0,1,3)]==[4,55,13]
assert 86-ranks[2,3]-ranks[2,4]==3
for x in letters:assert not q0(q0({(x,):F(1)}))
print('classical budgets 0,0,3,0,0 PASS',flush=True)
leading={};completed=[]
for j in (2,3,8):
 d=json.load(gzip.open(r/f'descendant{j}.json.gz','rt'));series={k:list(map(unpack,d[k])) for k in ('J_minus','J_plus','translation')}
 for name,Ps in series.items():
  assert len(Ps)==3
  for n,P in enumerate(Ps):
   assert all(len(w)==4-n and tuple(sum(i in x[0][2] for x in w) for i in range(3))==(2-n,)*3 for w in P)
   jets=(2+n,1+n) if name=='J_minus' else (1+n,2+n) if name=='J_plus' else (2+n,2+n)
   assert all(tuple(sum(x[0][i] for x in w) for i in (0,1))==jets for w in P)
  assert not q0(Ps[0]);assert zero(q0(Ps[1]),q1(Ps[0]));assert zero(q0(Ps[2]),q1(Ps[1]),q2(Ps[0]))
 for n in range(3):
  assert all(singlet_checks(series['translation'][n]));assert zero(deriv(series['J_minus'][n],1),deriv(series['J_plus'][n],0),{w:-c for w,c in series['translation'][n].items()})
 leading[j]=series['translation'][0];completed.append(j);print('completed descendant',j,'PASS',flush=True)
d=json.loads((r/'descendant-minor.json').read_text());rows=list(map(word,d['augmented_minor_rows']));cols=[images[j] if kind=='incoming' else leading[j] for kind,j in d['selected_original_columns']];minor=det([[mod(P.get(w,0)) for P in cols] for w in rows]);assert minor==d['determinant'] and minor
out={'status':'PASS','scope':'relative twisted complex; conditional on published Q(u) differential and finite filtration; not physical no-pairing','complete_classical_incoming_dimensions':[4,55,86,13,0],'classical_H_upper':[0,0,3,0,0],'k2_full_incoming_rank_Q':7,'completed_translation_reductions':completed,'augmented_original_minor_size':10,'augmented_original_minor_det':minor,'prime':p,'formal_incoming_translation_quotient_generators_upper':0,'higher_closure':'theta_i=2-n at coefficient n; every Q_m with m+n>=3 forbidden','minors':minors,'Q0_squared_source_letters':len(letters),'wall_seconds':time.monotonic()-t,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
print(json.dumps(out,indent=2));(r/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
