"""Standard-library-only exact A3 Taylor Q0 replay, no public/private implementation imports."""
import itertools as it,json,gzip,time,resource
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
odd=lambda x:(len(x[0][2])+1)%2
def add(o,w,c):
 a=[x for x in w if odd(x)]
 if len(a)!=len(set(a)):return
 s=(-1)**sum(a[i]>a[j] for i in range(len(a)) for j in range(i+1,len(a)));o[tuple(sorted(w))]+=c*s
@lru_cache(None)
def letter(x):
 (ap,am,S),a=x;o=defaultdict(F)
 for bp in range(ap+1):
  for bm in range(am+1):
   for mask in range(1<<len(S)):
    U=tuple(x for k,x in enumerate(S) if mask>>k&1);V=tuple(x for x in S if x not in U)
    if not U and bp+bm==0 or not V and ap+am-bp-bm==0:continue
    sign=(-1)**(len(S)+((len(U)+1)%2)*len(V)+sum(u>v for u in U for v in V))
    for b,c in it.permutations(range(3),2):
     if len({a,b,c})<3:continue
     eps=(-1)**((a>b)+(a>c)+(b>c));add(o,(((bp,bm,U),b),((ap-bp,am-bm,V),c)),F(sign*eps,2))
 return {w:c for w,c in o.items() if c}
def q0(P):
 o=defaultdict(F)
 for w,c in P.items():
  prefix=1
  for j,x in enumerate(w):
   for z,a in letter(x).items():add(o,w[:j]+z+w[j+1:],c*a*prefix)
   if odd(x):prefix=-prefix
 return {w:c for w,c in o.items() if c}

def clean(P):return {w:c for w,c in P.items() if c}
def E(a,b,c):
 if len({a,b,c})<3:return 0
 return (-1)**sum(x>y for i,x in enumerate((a,b,c)) for y in (a,b,c)[i+1:])

def act(P,kind,i=0,j=1):
 out=defaultdict(F)
 for w,c in P.items():
  for pos,((a,b,S),col) in enumerate(w):
   choices=[]
   if kind=='flavour':
    if j not in S or i in S:continue
    A=list(S);A[A.index(j)]=i;s=(-1)**sum(A[u]>A[t] for u in range(len(A)) for t in range(u+1,len(A)));choices=[(((a,b,tuple(sorted(A))),col),s)]
   elif kind=='spin':
    if i==0 and b:choices=[(((a+1,b-1,S),col),a+1)]
    if i==1 and a:choices=[(((a-1,b+1,S),col),b+1)]
   else:choices=[(((a,b,S),k),E(i,col,k)) for k in range(3) if E(i,col,k)]
   for z,s in choices:add(out,w[:pos]+(z,)+w[pos+1:],c*s)
 return clean(out)
def singlet_checks(P):
 return [not act(P,'flavour',i,j) for i,j in [(0,1),(1,2),(1,0),(2,1)]]+[not act(P,'spin',i) for i in (0,1)]+[not act(P,'colour',i) for i in range(3)]

