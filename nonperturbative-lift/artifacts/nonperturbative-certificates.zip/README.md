# Pure-SYM electronic certificates

This bundle contains selected exact polynomial witnesses, rational verification reports, proofs and verification scripts underlying the Chinese-English article. `manifest.json` lists the original source path, byte count and SHA256 of every included file.

The SU(2) full C0*C2 primitive is `rational_c4/C0_C2_boundary_exact.pkl`, dictionary field `boundary`; its formal hbar identity is documented by `C0_C2_boundary_readback.json`. The full C2*C2-3C0*C4_source primitive is `rational_c4/full_hidden_product_exact.pkl`, field `boundary`. Article convention uses C4_article=-C4_source.

The 686635425-byte SU(2) third-correction polynomial remains in the local archive; its original path and already-verified hash are recorded under `archived_local`. Its exact summary and independent readback are included. Other intermediate map columns, source-engine dependencies and environment installations remain in the original research archive. This is a certificate bundle, not a claim of a standalone reproducible environment.

Pickles are included as original research data. Read the supplied source descriptors and normalization notes before using their component coefficients.
