"""Exact independent Cartan Hessians; all symbols here are computational coordinates."""
from pathlib import Path
from functools import lru_cache
import sympy as s
import json,time
start=time.time();records=[]
for N in (3,4):
    x=s.symbols('x1:'+str(N));eig=(*x,-sum(x));u=s.symbols('u1:'+str(N));v=s.symbols('v1:'+str(N))
    ufull=(*u,-sum(u));vfull=(*v,-sum(v));z=s.Symbol('z')
    characteristic=s.Poly(s.prod(z-b for b in eig),z)
    cs={j:s.expand(characteristic.nth(N-j)) for j in range(2,N+1)}
    @lru_cache(None)
    def coefficient(beta,degree):
        if degree<0:return s.S.Zero
        out=s.S.Zero
        def walk(j,left,exponents):
            nonlocal out
            if j>N:
                if left:return
                count=sum(exponents.values());a=s.prod(beta-i for i in range(count))
                a*=s.prod(cs[t]**r/s.factorial(r) for t,r in exponents.items());out+=a;return
            for r in range(left//j+1):walk(j+1,left-j*r,{**exponents,j:r})
        walk(2,degree,{})
        return s.expand(out)
    C0=sum(a*b for a,b in zip(ufull,vfull))
    a1=-sum(b*a*d for b,a,d in zip(eig,ufull,vfull))
    x2=sum(b*b for b in eig)
    R=sum(b*b*a*d for b,a,d in zip(eig,ufull,vfull))-s.Rational(1,4)*sum(b*a for b,a in zip(eig,ufull))*sum(b*d for b,d in zip(eig,vfull))
    for k in range(17):
        period=coefficient(s.Rational(k+1,N),k+2)
        if N==3:
            leading=coefficient(s.Rational(k-2,3),k-1)*a1-coefficient(s.Rational(k-2,3),k)*C0
            factor=s.Rational((k+1)**2,3)
        else:
            beta=s.Rational(k-3,4)
            leading=(coefficient(beta,k)-x2*coefficient(beta,k-2)/4)*C0-coefficient(beta,k-1)*a1+coefficient(beta,k-2)*R
            factor=-s.Rational((k+1)**2,4)
        lp=s.Poly(s.expand(factor*leading),*u,*v)
        for i in range(N-1):
            for j in range(N-1):
                assert s.expand(s.diff(period,x[i],x[j])-lp.coeff_monomial(u[i]*v[j]))==0,(N,k,i,j)
        assert bool(period)==(k%N!=N-1)
        records.append({'N':N,'k':k,'ordinary_Hessian_slots':(N-1)**2,'factor':str(factor),'period_nonzero':bool(period)})
result={'status':'PASS','coordinates':'independent traceless eigenvalues; commuting markers label ordered first-ghost then second-ghost slots','exact_symbolic_degree_range':[0,16],'records':records,'seconds':time.time()-start}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({q:w for q,w in result.items() if q!='records'},indent=2))
