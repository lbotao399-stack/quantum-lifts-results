"""Reopen the final M4 certificate and check its assembly and finite equations."""
from pathlib import Path
import sys,pickle,json,hashlib,time
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
import exact_product as E

def load(name):
    with (ROOT/name).open('rb') as f:return pickle.load(f)

def main():
    start=time.time();data=load('M4_full_exact.pkl');parts=data['components']
    partial=load('components_partial.pkl');closed=data['final_closed_correction']
    assert len(parts)==4
    assert parts[:2]==partial[:2]
    assert parts[2]==E.add(partial[2],closed)
    assert parts[0]==data['leading_source']['compact']
    expected=[(3-r,5,7,7) for r in range(4)]
    for r,p in enumerate(parts):
        for word,value in p.items():
            nb=sum(u[0][0]=='b' for u in word);nc=sum(u[0][0]=='c' for u in word)
            assert (nb,nc,nb+sum(u[1] for u in word),nb+sum(u[2] for u in word))==expected[r]
    residuals=[]
    for r,p in enumerate(parts):
        terms=[E.T.q0(p)]
        for i in range(r):
            n=r-i
            if i==2:terms.append(E.Q1(parts[2]))
            else:terms.append(load('Q%d_component%d.pkl'%(n,i)))
        residual=E.add(*terms);assert not residual,('finite closure',r,len(residual))
        residuals.append(len(residual));print('CLOSURE',r,'PASS',flush=True)
    assert not E.T.q0(closed)
    digest=hashlib.sha256((ROOT/'M4_full_exact.pkl').read_bytes()).hexdigest()
    report=dict(passed=True,sha256=digest,component_terms=list(map(len,parts)),
                gradings=expected,closure_residual_terms=residuals,
                saved_partial_assembly=True,full_Q0_closed_correction=True,
                cached_high_Q_images='Qn_componenti were previously computed from the unchanged saved components; Q1 of the changed component was recomputed',
                higher_equations='zero because Qn lowers Nb by n',seconds=time.time()-start)
    (ROOT/'readback.json').write_text(json.dumps(report,indent=2)+'\n')
    summary=json.loads((ROOT/'summary.json').read_text());summary.update(certificate_sha256=digest,saved_file_readback=True)
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(report),flush=True)

if __name__=='__main__':main()
