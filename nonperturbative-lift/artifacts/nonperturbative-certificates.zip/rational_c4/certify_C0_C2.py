"""Close the omitted pure-c w0 gate for the saved SU2 C0-star-C2 boundary.

Use the preserved product convention and original full Q/product operators.
The old C0 is twice product C0, while old C2 is half product C2 at every
order; their product and the transported w2,w1 therefore require no scale.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,pickle,sys,time,resource
import exact_product as E
import exact_star as S
import certify_c4 as C
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'C0_C2_boundary_exact.pkl'
READBACK='--readback' in sys.argv
C.CHECK_PATH=ROOT/('C0_C2_boundary_readback_checks.json' if READBACK else 'C0_C2_boundary_checks.json')
START=time.time()

def load(path):
    with path.open('rb') as stream:return pickle.load(stream)

def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        while block:=stream.read(1<<20):digest.update(block)
    return digest.hexdigest()

def convert(polynomial):
    labels={'E':'e12','F':'e21','H':'h1'};result={}
    for word,value in polynomial.items():
        key,sign=E.T.canon(tuple((u[0][0]+labels[u[0][1:]],u[1],u[2]) for u in word))
        if sign:result[key]=result.get(key,F(0))+sign*value
    return E.T.fin(result)

def products(c0,c2):
    return [E.add(*(S.star_n(order-index,c0,c2[index]) for index in range(order+1)))
            for order in range(3)]

def full_q(order,polynomial):return E.T.q0(polynomial) if order==0 else E.T.qn(order,polynomial)

def verify(data):
    actual=products(data['C0'],data['C2'])
    for order in range(3):
        C.check('fresh full product coefficient order %d'%order,E.sub(actual[order],data['products'][order]))
        image=E.add(*(full_q(order-index,data['boundary'][index]) for index in range(order+1)))
        C.check('full C0 star C2 boundary equation order %d'%order,E.sub(image,actual[order]))
    for order,poly in enumerate(data['boundary']):
        for word in poly:
            nb=sum(u[0][0]=='b' for u in word);nc=sum(u[0][0]=='c' for u in word)
            assert (nb,nc,nb+sum(u[1] for u in word),nb+sum(u[2] for u in word))==(2-order,3,4,4)
        C.check('boundary rotation raising order %d'%order,E.Jp(poly))
        C.check('boundary rotation lowering order %d'%order,E.S.Jm(poly))

if not READBACK:
    old_path=ROOT.parent/'massey3_out.pkl';old=load(old_path)
    product_path=ROOT/'full_hidden_product_exact.pkl';product=load(product_path)
    first=load(ROOT/'C2_complete_exact.pkl')
    c0,c2=product['C0'],product['C2']
    C.check('old C0 is twice product C0',E.sub(convert(first['C0']),E.sc(c0,2)))
    for index,name in enumerate(('a2','a1','a0')):
        C.check('old %s is half product C2 component'%name,E.sub(convert(old[name]),E.sc(c2[index],F(1,2))))
    boundary=[convert(old['w2']),convert(old['w1'])]
    product_components=products(c0,c2)
    C.check('saved w2 full Q0 equation',E.sub(full_q(0,boundary[0]),product_components[0]))
    C.check('saved corrected w1 full equation',E.sub(E.add(full_q(0,boundary[1]),full_q(1,boundary[0])),product_components[1]))
    target=E.sub(product_components[2],E.add(full_q(1,boundary[1]),full_q(2,boundary[0])))
    C.check('last target full Q0 closure',E.T.q0(target))
    rows=[];sources=[];images=[];descriptors=[]
    for types in E.S.type_lists(0,3,4,4):
        for cycles in E.S.derangements(3):
            p=E.S.scalar(E.S.contract(types,cycles));q=E.T.q0(p)
            row={w:C.modq(c) for w,c in q.items() if c}
            for pivot,previous in rows:
                factor=row.get(pivot,0)
                if factor:
                    for word,value in previous.items():
                        updated=(row.get(word,0)-factor*value)%C.P
                        if updated:row[word]=updated
                        else:row.pop(word,None)
            if not row:continue
            pivot=min(row);factor=pow(row[pivot],-1,C.P)
            rows.append((pivot,{w:c*factor%C.P for w,c in row.items()}))
            sources.append(p);images.append(q);descriptors.append((types,cycles))
    coefficients,_=C.rational_solve(images,target)
    w0=E.add(*(E.sc(p,c) for p,c in zip(sources,coefficients)))
    C.check('new w0 full Q0 image equals exact last target',E.sub(E.T.q0(w0),target))
    boundary.append(w0)
    data={'C0':c0,'C2':c2,'products':product_components,'boundary':boundary,
        'last_target':target,'w0_source_descriptors':descriptors,'w0_coefficients':coefficients,
        'input_sha256':{'massey3_out.pkl':sha(old_path),'full_hidden_product_exact.pkl':sha(product_path)},
        'normalization':'unchanged product-engine convention; old C0=2 product C0 and old C2=(1/2)product C2',
        'formal_hbar':'w=w2+hbar*w1+hbar^2*w0; no negative hbar powers or division by hbar'}
    temporary=OUT.with_suffix('.tmp')
    with temporary.open('wb') as stream:pickle.dump(data,stream,protocol=4)
    temporary.replace(OUT)
else:data=load(OUT)
verify(data)
report={'passed':True,'saved_file_readback':READBACK,'certificate_sha256':sha(OUT),
    'product_terms':list(map(len,data['products'])),'boundary_terms':list(map(len,data['boundary'])),
    'last_target_terms':len(data['last_target']),'w0_rational_columns':len(data['w0_coefficients']),
    'full_boundary_residual_terms':[0,0,0],'all_bare_ghost_terms_included':True,
    'all_monomial_gradings_checked':True,'all_rotation_residual_terms':0,
    'relation':'C0 star C2 = Qpert(w2+hbar*w1+hbar^2*w0)',
    'formal_hbar':'exact over Q[hbar], hence over Q[[hbar]]; no hbar division',
    'higher_orders':'zero because the source components and product have at most2 b letters',
    'seconds':time.time()-START,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
name='C0_C2_boundary_readback.json' if READBACK else 'C0_C2_boundary_summary.json'
(ROOT/name).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
