#!/usr/bin/env python3
"""Exact rational Cartan restrictions of six Q0-closed C0-product targets.

The full lifts are products of derivatives of C0=tr(d1 c d2 c),
projected to rotation spin zero. Restriction commutes with jets and rotation.
This verifier uses rational exterior-polynomial arithmetic independently of
sunlib/qengine and checks each stored finite-field polynomial.
"""
import json
import math
import pathlib
import pickle
from fractions import Fraction as F

ROOT = pathlib.Path(__file__).resolve().parent
P = 2147483647


def canon(word):
    if len(set(word)) != len(word):
        return (), 0
    inversions = sum(word[i] > word[j] for i in range(len(word))
                     for j in range(i + 1, len(word)))
    return tuple(sorted(word)), (-1 if inversions % 2 else 1)


def clean(poly):
    return {word: value for word, value in poly.items() if value}


def mul(left, right):
    out = {}
    for left_word, left_value in left.items():
        for right_word, right_value in right.items():
            word, sign = canon(left_word + right_word)
            if sign:
                out[word] = out.get(word, F(0)) + sign * left_value * right_value
    return clean(out)


def action(poly, kind):
    out = {}
    for word, value in poly.items():
        for i, (name, r, s) in enumerate(word):
            if kind == 'd1':
                coefficient, jet = 1, (name, r + 1, s)
            elif kind == 'd2':
                coefficient, jet = 1, (name, r, s + 1)
            elif kind == 'J+':
                coefficient, jet = s, (name, r + 1, s - 1)
            elif kind == 'J-':
                coefficient, jet = r, (name, r - 1, s + 1)
            else:
                raise ValueError(kind)
            if coefficient:
                result, sign = canon(word[:i] + (jet,) + word[i + 1:])
                if sign:
                    out[result] = out.get(result, F(0)) + sign * coefficient * value
    return clean(out)


def jet(poly, r, s):
    for _ in range(r):
        poly = action(poly, 'd1')
    for _ in range(s):
        poly = action(poly, 'd2')
    return poly


def scalar(poly):
    for j in range(1, 10):
        correction = action(action(poly, 'J+'), 'J-')
        for word, value in correction.items():
            poly[word] = poly.get(word, F(0)) - value / (j * (j + 1))
        poly = clean(poly)
    assert not action(poly, 'J+')
    return poly


def determinant(matrix):
    matrix = [row[:] for row in matrix]
    value = F(1)
    for j in range(len(matrix)):
        pivot = next(i for i in range(j, len(matrix)) if matrix[i][j])
        if pivot != j:
            matrix[j], matrix[pivot] = matrix[pivot], matrix[j]
            value = -value
        pivot_value = matrix[j][j]
        value *= pivot_value
        for i in range(j + 1, len(matrix)):
            factor = matrix[i][j] / pivot_value
            for k in range(j, len(matrix)):
                matrix[i][k] -= factor * matrix[j][k]
    return value


def mod(value):
    return value.numerator * pow(value.denominator, -1, P) % P


saved = pickle.loads((ROOT / 'cartan_target_classes.pkl').read_bytes())
assert len(saved) == 6
# tr(H^2)=2 in the original Chevalley basis; fermions are canonically sorted.
C0 = {(('ch1', 0, 1), ('ch1', 1, 0)): F(-2)}
polynomials = []
rows = []
for n, item in enumerate(saved, 1):
    poly = {(): F(1)}
    for r, s in item['jets']:
        poly = mul(poly, jet(C0, r, s))
    poly = scalar(poly)
    assert {word: mod(value) for word, value in poly.items()} == item['poly']
    polynomials.append(poly)
    reduced = dict(poly)
    for pivot, row in rows:
        factor = reduced.get(pivot, F(0))
        if factor:
            for word, value in row.items():
                reduced[word] = reduced.get(word, F(0)) - factor * value
            reduced = clean(reduced)
    assert reduced
    pivot = min(reduced)
    pivot_value = reduced[pivot]
    rows.append((pivot, {word: value / pivot_value for word, value in reduced.items()}))
    print('exact target', n, 'jets', item['jets'], 'Cartan monomials', len(poly), flush=True)

columns = [pivot for pivot, _ in rows]
minor = [[poly.get(word, F(0)) for word in columns] for poly in polynomials]
det = determinant(minor)
assert det
result = {
    'target_Nb': 0, 'target_Nc': 6, 'weight': [9, 9],
    'coefficient_field': 'Q', 'rank': 6,
    'normalization': 'C0 = tr(d1 c d2 c); Chevalley H has tr(H^2)=2',
    'construction': 'rotation-scalar projection of products of three C0 derivatives',
    'descriptors': [item['jets'] for item in saved],
    'columns': [[list(letter) for letter in word] for word in columns],
    'minor_Q': [[str(value) for value in row] for row in minor],
    'determinant_Q': str(det), 'prime': P, 'determinant_mod_p': mod(det),
    'polynomials_Q': [
        [{'word': [list(letter) for letter in word], 'coefficient': str(value)}
         for word, value in sorted(poly.items())] for poly in polynomials
    ],
    'finite_field_saved_polynomials_match': True,
}
(ROOT / 'cartan_target_certificate.json').write_text(json.dumps(result, indent=2) + '\n')
print('RATIONAL TARGET CERTIFICATE', 'rank', len(rows), 'det', det,
      'mod p', mod(det), flush=True)
