"""Read-only exact bridge between the two retained SU2 source conventions."""
import os,sys,pickle,json
from pathlib import Path
from fractions import Fraction as F
os.environ['SUN']='2'
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'rational_c4'))
import exact_product as E
first=pickle.load(open(ROOT/'rational_c4/C2_complete_exact.pkl','rb'))
product=pickle.load(open(ROOT/'rational_c4/full_hidden_product_exact.pkl','rb'))
labels={'E':'e12','F':'e21','H':'h1'}
def convert(poly):
    out={}
    for word,coefficient in poly.items():
        new,sign=E.T.canon(tuple((u[0][0]+labels[u[0][1:]],u[1],u[2]) for u in word))
        if sign:out[new]=out.get(new,F(0))+sign*coefficient
    return E.T.fin(out)
records=[]
for key,reference,ratio in [('C0',product['C0'],F(2)),
                          ('C2_Nb2',product['C2'][0],F(1,2)),
                          ('C2_Nb1',product['C2'][1],F(1,2)),
                          ('C2_Nb0',product['C2'][2],F(1,2))]:
    assert convert(first[key])==E.sc(reference,ratio)
    records.append({'component':key,'ratio_first_artifact_to_product':str(ratio),'literal_polynomial_residual':0})
result={'status':'PASS','first_artifact':'rational_c4/C2_complete_exact.pkl',
        'product_artifact':'rational_c4/full_hidden_product_exact.pkl',
        'color_label_map':labels,'Grassmann_reordering':'source canonical ordering applied with its exact sign',
        'records':records,'scope':'explicit comparison only; neither saved convention is changed'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
