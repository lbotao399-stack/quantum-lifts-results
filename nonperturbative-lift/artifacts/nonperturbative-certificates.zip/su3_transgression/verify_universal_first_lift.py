"""Independent universal first-lift construction from five exact primitive identities."""
import sys,pickle,json,time
from pathlib import Path
import sympy as sp
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'su3_rational'))
from rational_su3 import *
import fast_wick_edges,fast_selected_direct
fast_wick_edges.install(T);fast_selected_direct.install(T)
module=pickle.load(open(ROOT/'su3_rational/leading_module_Q.pkl','rb'))
first=pickle.load(open(ROOT/'su3_rational/radial_first_primitives_Q.pkl','rb'))
brackets=pickle.load(open(Path(__file__).with_name('casimir_brackets.pkl'),'rb'))
q2,q3=module['trace2'],module['trace3']
C0,a1=module['generators'][:2]
P3=first['first_relation']['primitive'];P4=first['second_relation']['primitive']
P22,P23,P33=[record['primitive'] for record in brackets]
start=time.time()
assert all(T.q0(record['primitive'])==record['bracket'] for record in brackets)
assert T.q0(P3)==first['first_relation']['target']
assert T.q0(P4)==first['second_relation']['target']
assert not T.qn(1,C0) and not T.qn(1,a1)
A=T.qn(1,mul(q2,C0));B=T.qn(1,mul(q3,C0))
assert sub(T.qn(1,mul(q2,a1)),sc(B,F(2,3)))==T.q0(P3)
assert sub(T.qn(1,mul(q3,a1)),sc(mul(q2,A),F(1,4)))==T.q0(P4)

# Temporary computational polynomial variables, never a source normalization.
x,y=sp.symbols('x y')
cache={}
def evaluate(poly):
    out={}
    for (a,d),coefficient in sp.Poly(poly,x,y).terms():
        if coefficient==0:continue
        if (a,d) not in cache:cache[a,d]=mul(*([q2]*a+[q3]*d))
        out=add(out,sc(cache[a,d],F(coefficient)))
    return out

def pair(f0,f1):
    return add(mul(evaluate(f0),C0),mul(evaluate(f1),a1))

def primitive(f0,f1):
    return add(mul(evaluate(sp.diff(f1,x)),P3),mul(evaluate(sp.diff(f1,y)),P4),
               sc(mul(P22,pair(sp.diff(f0,x,2),sp.diff(f1,x,2))),F(1,2)),
               mul(P23,pair(sp.diff(f0,x,y),sp.diff(f1,x,y))),
               sc(mul(P33,pair(sp.diff(f0,y,2),sp.diff(f1,y,2))),F(1,2)))

tests=[('k7',-2*x*x*y,x**3+8*y*y),('off_kernel',x*x,x*y)]
records=[];witnesses=[]
for name,f0,f1 in tests:
    leading=pair(f0,f1);transgression=primitive(f0,f1)
    Q1leading=T.qn(1,leading)
    remaining=add(mul(evaluate(sp.diff(f0,x)+x*sp.diff(f1,y)/4),A),
                  mul(evaluate(sp.diff(f0,y)+sp.Rational(2,3)*sp.diff(f1,x)),B))
    assert sub(Q1leading,T.q0(transgression))==remaining
    if name=='k7':assert not remaining
    else:assert remaining
    record={'name':name,'C0_coefficient':str(f0),'a1_coefficient':str(f1),
            'leading_terms':len(leading),'Q1_terms':len(Q1leading),
            'primitive_terms':len(transgression),'nonexact_remainder_terms':len(remaining),
            'full_Q0_identity':True}
    records.append(record)
    witnesses.append({'record':record,'leading':leading,'first_correction':sc(transgression,-1),
                      'Q1_leading':Q1leading,'remainder':remaining})
    print(record,flush=True)
result={'status':'PASS','five_primitive_identities_read_back':True,
        'tests':records,'seconds':time.time()-start,
        'scope':'universal full-Q0 first-lift identity; k7 is an E2 survivor, higher loop closure not claimed'}
Path(__file__).with_suffix('.pkl').write_bytes(pickle.dumps(witnesses))
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
