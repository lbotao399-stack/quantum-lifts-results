"""Exact formal audit of the SU4 finite-primitive transgression recipe.
Source polynomial gates are read separately; this checks their universal algebra.
"""
from pathlib import Path
import sympy as s
import json,hashlib
out=Path(__file__).resolve().parent
x,y,z=s.symbols('x y z');xs=(x,y,z)
C,A,R,qR=s.symbols('C A R qR');gens=(C,A,R)
ops=s.Matrix(3,3,lambda i,j:s.Symbol(f'op_{i}_{j}'))
B=s.Matrix(3,3,lambda i,j:s.Symbol(f'B_{min(i,j)}_{max(i,j)}'))
def q1(fs):
    return s.expand(fs[2]*qR+sum(s.diff(f,t)*ops[i,j] for i,f in enumerate(fs) for j,t in enumerate(xs))+
       sum(g*sum(s.diff(f,t,u)*B[j,l]/2 for j,t in enumerate(xs) for l,u in enumerate(xs)) for g,f in zip(gens,fs)))
lead2=(x/2,0,-4);lead4=(-s.Rational(5,16)*x*x+z/2,-s.Rational(2,3)*y,x)
lead5=(0,s.Rational(3,16)*x*x-s.Rational(3,4)*z,y)
lead6=(x*z-s.Rational(11,24)*x**3-s.Rational(4,9)*y*y,s.Rational(4,3)*x*y,3*x*x-8*z)
# The saved k2 correction has the opposite image to Q1(lead2).
P0=-q1(lead2)/4
Px=q1(lead4)-x*P0+s.Rational(5,16)*B[0,0]*C
Py=q1(lead5)-y*P0-s.Rational(3,16)*B[0,0]*A
Pz=((3*x*x-8*z)*P0+6*x*Px+3*B[0,0]*R-s.Rational(11,8)*x*B[0,0]*C+B[0,2]*C-s.Rational(4,9)*B[1,1]*C+s.Rational(4,3)*B[0,1]*A-q1(lead6))/8
expected=[qR-ops[0,0]/8,
 ops[2,0]-x*ops[0,0]/2+ops[0,2]/2-s.Rational(2,3)*ops[1,1],
 ops[2,1]+y*ops[0,0]/8+3*x*ops[1,0]/8-3*ops[1,2]/4,
 ops[2,2]-x*x*ops[0,0]/4+x*ops[0,2]/4+y*ops[0,1]/9-y*ops[1,0]/6-s.Rational(2,3)*x*ops[1,1]]
assert all(s.expand(a-b)==0 for a,b in zip([P0,Px,Py,Pz],expected))
f,g,r=[s.Function(a)(x,y,z) for a in ('f','g','r')]
primitive=r*P0+s.diff(r,x)*Px+s.diff(r,y)*Py+s.diff(r,z)*Pz
primitive+=sum(gen*sum(s.diff(fun,t,u)*B[j,l]/2 for j,t in enumerate(xs) for l,u in enumerate(xs)) for gen,fun in zip(gens,(f,g,r)))
pde=[s.diff(f,x)+r/8+x*s.diff(r,x)/2-y*s.diff(r,y)/8+x*x*s.diff(r,z)/4,
 s.diff(f,y)-y*s.diff(r,z)/9,
 s.diff(g,x)-3*x*s.diff(r,y)/8+y*s.diff(r,z)/6,
 s.diff(f,z)-s.diff(r,x)/2-x*s.diff(r,z)/4,
 s.diff(g,y)+s.Rational(2,3)*s.diff(r,x)+s.Rational(2,3)*x*s.diff(r,z),
 s.diff(g,z)+s.Rational(3,4)*s.diff(r,y)]
bases=[ops[0,0],ops[0,1],ops[1,0],ops[0,2],ops[1,1],ops[1,2]]
assert s.expand(q1((f,g,r))-primitive-sum(a*b for a,b in zip(pde,bases)))==0
# Independently compare the three radial relations to the saved source map.
saved=json.loads((out/'radial_equations.json').read_text())
for row in saved['derivative_relations']:
 if row['generator']!=2:continue
 j=row['coordinate']-2
 image=sum(s.Rational(t['coefficient'])*s.prod(a**n for a,n in zip(xs,t['Casimir_powers']))*bases[t['base']] for t in row['terms'])
 assert s.expand(expected[j+1]-(ops[2,j]-image))==0
checks={}
for k in (4,5,6):
 p=out/f'k{k}_first/independent_readback.json'
 checks[str(k)]=json.loads(p.read_text()).get('status') if p.exists() else 'PENDING'
result={'formal_chain_rule_status':'PASS','zeroth_and_three_first_relations':True,'second_derivative_diagonal_factor':'1/2','mixed_unordered_factor':'1','six_residual_coefficients':[str(a) for a in pde],
 'saved_radial_relations_match':True,'independent_source_gates':checks,
 'full_E2_claim_authorized':all(v=='PASS' for v in checks.values()) and json.loads((out/'k2_independent_readback.json').read_text())['status']=='PASS',
 'scope':'exact universal algebra; source gates separately mandatory'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
