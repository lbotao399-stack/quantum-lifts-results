#!/usr/bin/env python3
"""Prove Cartan(Q1 z)=0 for every scalar gauge-invariant Q0 cocycle z.

Construct an exact rational functional f with detector*Q1=f*Q0, then
verify the equality on a certified complete invariant basis. The detector
is one nonzero coefficient of the rational one-dimensional target class.
"""
import gc
import hashlib
import json
import math
import pathlib
import pickle
import time
from rational_su3 import *

started = time.time()
prime = 2147483647
capture = pickle.load(open('stageC1_descriptors.pkl', 'rb'))
indices = list(capture['coefficients'][0])
dimension = 3 * len(indices) + 7
hashes = {}
coefficient_mod = {}
target_data = pickle.load(open('partner_Q.pkl', 'rb'))
detector_word = min(target_data['cartan'])
detector_value = target_data['cartan'][detector_word]
del target_data


def hash_word(word):
    if word not in hashes:
        digest = hashlib.blake2b(repr(word).encode(), digest_size=16).digest()
        hashes[word] = (int.from_bytes(digest[:8], 'little'),
                        1 if digest[8] & 1 else -1)
    return hashes[word]


def integer_sketch(poly):
    denominator = 1
    for value in poly.values():
        denominator = math.lcm(denominator, value.denominator)
    result = [0] * dimension
    for word, value in poly.items():
        number, sign = hash_word(word)
        result[number % dimension] += sign * value.numerator * (denominator // value.denominator)
    return result, denominator


def solve(matrix, right):
    matrix = [[F(value) for value in row] + [F(value)]
              for row, value in zip(matrix, right)]
    size = len(matrix)
    for j in range(size):
        pivot = next(i for i in range(j, size) if matrix[i][j])
        matrix[j], matrix[pivot] = matrix[pivot], matrix[j]
        for i in range(j + 1, size):
            factor = matrix[i][j] / matrix[j][j]
            if factor:
                for k in range(j, size + 1):
                    matrix[i][k] -= factor * matrix[j][k]
    result = [F(0)] * size
    for j in range(size - 1, -1, -1):
        result[j] = (matrix[j][-1] - sum(matrix[j][k] * result[k]
                     for k in range(j + 1, size))) / matrix[j][j]
    return result


class ModSpan:
    def __init__(self):
        self.rows = []
        self.coordinates = []
        self.pivots = []

    def insert(self, vector):
        vector = [value % prime for value in vector]
        for pivot, row in self.rows:
            factor = vector[pivot]
            if factor:
                vector = [(a - factor * b) % prime for a, b in zip(vector, row)]
        pivot = next((i for i, value in enumerate(vector) if value), None)
        if pivot is None:
            return False
        self.coordinates.append(pivot)
        self.pivots.append(vector[pivot])
        factor = pow(vector[pivot], -1, prime)
        self.rows.append((pivot, [value * factor % prime for value in vector]))
        return True


cached = pickle.load(open('n1_partial_basis_Q.pkl', 'rb'))
vectors = cached['vectors'][:]
denominators = cached['denominators'][:]
sources = cached['sources'][:]
for index in indices[len(sources):]:
    descriptor = capture['descriptors'][index]
    source = scalar(contract(descriptor['types'], descriptor['cycles']))
    vector, denominator = integer_sketch(Q0(source))
    vectors.append(vector)
    denominators.append(denominator)
    sources.append(source)
assert len(sources) == 44
image_span = ModSpan()
for vector in vectors:
    assert image_span.insert(vector)
coordinates = image_span.coordinates
values = [q1_cartan(source)[0].get(detector_word, F(0)) for source in sources]
functional = solve([[vector[i] for i in coordinates] for vector in vectors],
                   [value * denominator for value, denominator in zip(values, denominators)])
print('Exact detector functional solved on 44 independent Q0 images', flush=True)
del cached, sources, vectors, denominators
gc.collect()

source_span = ModSpan()
source_vectors = []
descriptors = []
source_hash_dimension = 509


def source_sketch(poly):
    result = [0] * source_hash_dimension
    for word, value in poly.items():
        if value not in coefficient_mod:
            coefficient_mod[value] = value.numerator * pow(value.denominator, -1, prime) % prime
        number, sign = hash_word(word)
        result[number % source_hash_dimension] = (
            result[number % source_hash_dimension] + sign * coefficient_mod[value]) % prime
    return result


types = type_lists(1, 6, 4, 4)
cycles = derangements(7)
pool = [(i, j) for i in range(len(types)) for j in range(len(cycles))]
random.Random(9).shuffle(pool)
for trial, (i, j) in enumerate(pool[:1500], 1):
    source = scalar(contract(types[i], cycles[j]))
    if not source:
        continue
    source_vector = source_sketch(source)
    if not source_span.insert(source_vector):
        continue
    value = q1_cartan(source)[0].get(detector_word, F(0))
    image_vector, denominator = integer_sketch(Q0(source))
    predicted = sum(coefficient * image_vector[coordinate]
                    for coefficient, coordinate in zip(functional, coordinates)) / denominator
    if value != predicted:
        pickle.dump(dict(source=source, descriptor={'types': types[i], 'cycles': cycles[j]},
                         actual=value, predicted=predicted), open('incoming_factorization_failed.pkl', 'wb'))
        raise RuntimeError('rational factorization failed')
    descriptors.append({'types': types[i], 'cycles': cycles[j]})
    source_vectors.append(source_vector)
    rank = len(source_span.rows)
    if rank % 10 == 0 or rank == 165:
        print('basis rank', rank, 'trial', trial, 'exact functional identity passed',
              'seconds', round(time.time() - started, 2), flush=True)
        pickle.dump(dict(descriptors=descriptors, source_vectors=source_vectors,
                         functional=functional, coordinates=coordinates),
                    open('incoming_factorization_partial.pkl', 'wb'))
    if rank == 165:
        break

assert len(source_span.rows) == 165, 'bounded sample did not span the invariant source'
determinant_mod = 1
for pivot in source_span.pivots:
    determinant_mod = determinant_mod * pivot % prime
certificate = {
    'coefficient_field': 'Q', 'source': {'Nb': 1, 'Nc': 6, 'weight': [5, 5]},
    'source_scalar_dimension_exact': 165, 'basis_rank_mod_p': 165, 'prime': prime,
    'basis_minor_determinant_mod_p': determinant_mod,
    'basis_minor': [[vector[i] for i in source_span.coordinates] for vector in source_vectors],
    'basis_minor_coordinates': source_span.coordinates,
    'source_descriptors': descriptors,
    'detector_word': [list(letter) for letter in detector_word],
    'detector_value_on_partner_Q': str(detector_value),
    'image_sketch_dimension': dimension,
    'image_sketch_coordinates': coordinates,
    'functional_Q': list(map(str, functional)),
    'exact_identity': 'detector composed with Q1 = functional composed with sketch composed with Q0',
    'all_basis_residuals_Q': 0,
    'consequence': 'incoming d1 into the one-dimensional target H(Q0)^(0,7) is zero over Q',
    'trials': trial, 'seconds': time.time() - started,
}
pathlib.Path('incoming_d1_Q_certificate.json').write_text(json.dumps(certificate, indent=2) + '\n')
print('INCOMING D1 ZERO OVER Q: PASS', flush=True)
