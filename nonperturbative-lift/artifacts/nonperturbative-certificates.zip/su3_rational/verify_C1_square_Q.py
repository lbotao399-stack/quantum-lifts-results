#!/usr/bin/env python3
"""Exact leading C1-square class and source-normalized classical trace relations."""
import json
import os
import pathlib
import pickle
import subprocess
from rational_su3 import *

root = pathlib.Path(__file__).resolve().parent
A = pickle.load(open(root / 'stageA_Q.pkl', 'rb'))
C0, a1 = A['C0'], A['a1']
b2_trace = cyc_poly([('b', 0, 0), ('b', 0, 0)])
trace_combination = add(
    cyc_poly([('b', 0, 0), ('b', 0, 0), ('c', 1, 0), ('c', 0, 1)]),
    sc(cyc_poly([('b', 0, 0), ('b', 0, 0), ('c', 0, 1), ('c', 1, 0)]), -1),
    cyc_poly([('b', 0, 0), ('c', 1, 0), ('b', 0, 0), ('c', 0, 1)]))
square = mul(a1, a1)
first_relation = sc(mul(C0, trace_combination), F(-1, 6))
second_relation = sc(mul(b2_trace, C0, C0), F(-1, 6))
assert all(not Q0(poly) for poly in [square, first_relation, second_relation])
restriction = cartan(square)
assert restriction and restriction == cartan(first_relation) == cartan(second_relation)
assert set(restriction.values()) == {F(-2, 3)} and len(restriction) == 3

env = dict(os.environ)
env.pop('ROTATION_SINGLET', None)
command = [str(root.parent / 'c6_survival' / 'bfs'), '3', '4', '4', 'RQ0', '2', '3', '45', '191', '1']
rank = json.loads(subprocess.check_output(command, text=True, env=env))
assert rank['rank'] == 19 and rank['bad'] == 0
pickle.dump(dict(square=square, trace_combination=trace_combination,
                 first_relation=first_relation, second_relation=second_relation,
                 Cartan=restriction), open(root / 'C1_square_Q.pkl', 'wb'))
result = {
    'coefficient_field': 'Q', 'weight': [4, 4], 'Nb': 2, 'Nc': 4,
    'leading_square_terms': len(square), 'target_gauge_dimension': 20,
    'Q0_in_rank_Q': 19, 'Q0_out_rank_Q': 0, 'target_E1_dimension_Q': 1,
    'rank_evidence': rank,
    'Cartan': [{'word': [list(letter) for letter in word], 'coefficient_Q': str(value)}
               for word, value in sorted(restriction.items())],
    'classical_cohomology_relation_1': '[a1^2] = -1/6 [C0 tr(b^2 d1c d2c - b^2 d2c d1c + b d1c b d2c)]',
    'classical_cohomology_relation_2': '[a1^2] = -1/6 [tr(b^2) C0^2]',
    'literal_polynomial_difference_terms': [len(sub(square, first_relation)), len(sub(square, second_relation))],
    'relation_scope': 'equalities in H(Q0); differences are Q0-exact by the one-dimensional target and injective Cartan detector',
    'incoming_dr_r_ge1': 'source has Nb=2+r,Nc=3 and minimum weight7+2r>8',
    'quantum_product_nonzero': 'the source quantum chain-map product of the exact cocycle a1 with itself has this nonzero leading class and no possible incoming differential',
    'interpretation': 'nonzero leading product; no E_infinity generator C2 at(3,3) is introduced',
}
(root / 'C1_square_Q_certificate.json').write_text(json.dumps(result, indent=2) + '\n')
print('C1 SQUARE NONZERO; EXACT CLASSICAL COHOMOLOGY TRACE RELATIONS PASS', flush=True)
