#!/usr/bin/env python3
"""Certify the complete perturbative source of C0^2 in the partner degree."""
import hashlib
import json
import os
import pathlib
import pickle
import subprocess
from rational_su3 import *

root = pathlib.Path(__file__).resolve().parent
binary = root.parent / 'c6_survival' / 'bfs'
census_path = pathlib.Path('/Users/libotao/np_lifts_engine/results2_N3_3_3.json')
census = json.loads(census_path.read_text())
dimensions = {}
for nb, nc in [(0, 3), (1, 2), (1, 3), (1, 4), (2, 2), (2, 3)]:
    values = [census['DIM ' + str(nb) + ' ' + str(nc) + ' ' + ' '.join(map(str, weight))]['dim']
              for weight in [(0, 0, 0), (1, -1, 0), (2, -1, -1), (2, 0, -2)]]
    dimensions[str((nb, nc))] = {'weight_counts': values,
                                  'gauge_invariant_dimension': values[0] - 2 * values[1] + 2 * values[2] - values[3]}

env = dict(os.environ)
env.pop('ROTATION_SINGLET', None)
ranks = {}
for mode, nb, nc, samples, seed in [('RQ0', 0, 2, 25, 131), ('RQ0', 0, 3, 30, 137),
                                    ('RQ0', 1, 1, 25, 139), ('RQ0', 1, 2, 30, 149),
                                    ('RQ0', 1, 3, 25, 151), ('RD', 2, 2, 35, 157),
                                    ('RD', 1, 3, 45, 163)]:
    command = [str(binary), '3', '3', '3', mode, str(nb), str(nc), str(samples), str(seed), '1']
    proc = subprocess.run(command, text=True, capture_output=True, env=env, check=True)
    value = json.loads(proc.stdout)
    assert value['bad'] == 0
    ranks[f'{mode} {nb} {nc}'] = value
    print(mode, nb, nc, 'rank', value['rank'], flush=True)

A = pickle.load(open(root / 'stageA_Q.pkl', 'rb'))
descendant = T.jet(A['a1'], 1, 1)
assert not Q0(descendant)
restriction = cartan(descendant)
assert restriction
pickle.dump(descendant, open(root / 'a1_derivative_Q.pkl', 'wb'))
assert dimensions['(0, 3)']['gauge_invariant_dimension'] == 19
assert dimensions['(1, 2)']['gauge_invariant_dimension'] == 19
assert dimensions['(1, 3)']['gauge_invariant_dimension'] == 24
assert dimensions['(1, 4)']['gauge_invariant_dimension'] == 8
assert dimensions['(2, 3)']['gauge_invariant_dimension'] == 0
assert ranks['RQ0 0 2']['rank'] == 6 and ranks['RQ0 0 3']['rank'] == 13
assert ranks['RQ0 1 1']['rank'] == 6 and ranks['RQ0 1 2']['rank'] == 12
assert ranks['RQ0 1 3']['rank'] == 8
assert ranks['RD 2 2']['rank'] == 14 and ranks['RD 1 3']['rank'] == 23
result = {
    'source_weight': [3, 3], 'source_Nc': 3,
    'permitted_Nb': [0, 1], 'Nb_bound': '6 - 2 Nb >= 3',
    'dimensions': dimensions, 'independently_seeded_rank_lower_bounds': ranks,
    'rational_descendant': {'formula': 'd1 d2 a1', 'terms': len(descendant),
                             'Cartan_terms': len(restriction), 'Q0_terms': 0},
    'rank_control_Q': {'Q0_(0,2)': 6, 'Q0_(0,3)': 13, 'Q0_(1,1)': 6,
                       'Q0_(1,2)': 12, 'Q0_(1,3)': 8, 'Q0_(2,2)': 0},
    'source_E1_(0,3)_dimension_Q': 0,
    'source_E1_(1,3)_dimension_upper_Q': 4,
    'incoming_d1_rank_lower_Q': 2, 'outgoing_d1_rank_lower_Q': 2,
    'source_E2_Nc3_all_Nb_dimension_Q': 0,
    'source_E_infinity_Nc3_all_Nb_dimension_Q': 0,
    'C0_squared_image_in_partner_degree_dimension_Q': 0,
    'partner_quotient_dimension_Q': 1,
    'a1_outside_C0_squared_image': 'a1 has Nc2; a source would require Nc=-2',
    'quantum_product_scope': 'any well-defined multiplication by C0^2 on perturbative cohomology, including all quantum corrections',
    'source_census_sha256': hashlib.sha256(census_path.read_bytes()).hexdigest(),
    'rank_binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
}
(root / 'C0_squared_image_certificate.json').write_text(json.dumps(result, indent=2) + '\n')
print('C0^2 IMAGE ZERO OVER Q; PARTNER QUOTIENT NONZERO: PASS', flush=True)
