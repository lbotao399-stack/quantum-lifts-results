#!/usr/bin/env python3
"""Verify the complete pure-ghost SU3 first-partner cocycle over Q."""
import json
import pathlib
import pickle
import time
from rational_su3 import *

started = time.time()
A = pickle.load(open('stageA_Q.pkl', 'rb'))
C0, x, a1, th, w1, w0 = (A[key] for key in ['C0', 'x', 'a1', 'th', 'w1', 'w0'])
eta = pickle.load(open('eta_Q.pkl', 'rb'))
n1 = pickle.load(open('n1_Q.pkl', 'rb'))
m1 = pickle.load(open('n1_target_Q.pkl', 'rb'))
theta = deriv(th, False)
etaop = deriv({(0, 0): eta}, True)
m0 = sub(sub(etaop(a1), mul(C0, C0, w0)), sc(mul(C0, theta(w1)), 2))
print('m0', len(m0), 'seconds', round(time.time() - started, 2), flush=True)
chain_residual = add(Q1(m1), Q0(m0))
print('Q1 m1 + Q0 m0', len(chain_residual), 'seconds', round(time.time() - started, 2), flush=True)
assert not chain_residual
q1n1 = Q1(n1)
partner = sub(m0, q1n1)
print('Q1 n1', len(q1n1), 'reduced partner', len(partner),
      'seconds', round(time.time() - started, 2), flush=True)
assert not Q0(partner)
assert all(all(letter[0][0] == 'c' for letter in word) for word in partner)
assert not Jp(partner)
for which in range(2):
    assert not graise(partner, which)
restriction = cartan(partner)
assert len(restriction) == 6
assert set(restriction.values()) == {F(40), F(-40)}
assert cartan(q1n1) == {}
pickle.dump(dict(m0=m0, Q1n1=q1n1, partner=partner, cartan=restriction),
            open('partner_Q.pkl', 'wb'))
certificate = {
    'coefficient_field': 'Q', 'weight': [5, 5], 'Nb': 0, 'Nc': 7,
    'm1_terms': len(m1), 'n1_terms': len(n1), 'm0_terms': len(m0),
    'Q1n1_terms': len(q1n1), 'partner_terms': len(partner),
    'Q0_partner_terms': 0, 'chain_residual_terms': 0,
    'Q1n1_Cartan_terms': 0, 'Cartan_terms': len(restriction),
    'Cartan': [{'word': [list(letter) for letter in word], 'coefficient_Q': str(value)}
               for word, value in sorted(restriction.items())],
    'verified_gauge_invariance': True, 'verified_rotation_scalar': True,
    'outgoing_higher_Qn': 'zero by absence of b letters',
    'Q0_nonexact': 'nonzero Cartan restriction; every Q0 boundary restricts to zero',
    'full_nonexactness_status': 'see incoming_d1_Q_certificate.json and proofs.md Theorem 6',
    'seconds': time.time() - started,
}
pathlib.Path('partner_Q_certificate.json').write_text(json.dumps(certificate, indent=2) + '\n')
print('EXACT RATIONAL PARTNER COCYCLE PASS', flush=True)
