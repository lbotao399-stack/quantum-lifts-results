#!/usr/bin/env python3
"""Fresh trace reconstruction and full, chunked polynomial readback through hbar2."""
import json
from pathlib import Path
import pickle
import time
from rational_su3 import *
from trace_space_Q import from_descriptor
import fast_wick_edges
fast_wick_edges.install(T)
import fast_selected_direct
fast_selected_direct.install(T)
root=Path(__file__).resolve().parent;out=root/'k6_two_loop';start=time.time()
saved=pickle.load(open(out/'joint_two_loop_Q.pkl','rb'));components=saved['components']
first=pickle.load(open(out/'basis_Nb5_Nc2.pkl','rb'))
tower=pickle.load(open(root/'leading_tower_Q.pkl','rb'))[6]
b=('b',0,0);trace2=cyc_poly([b,b]);trace3=cyc_poly([b,b,b])
leading={}
for index,coefficient in tower['coefficients'][0].items():
    d=tower['descriptors'][index];i,j=d['gaps'];c2=('c',0,1);c1=('c',1,0)
    poly=cyc_poly([b]*i+[c2]+[b]*j+[c1]) if d['channel']=='single' else mul(cyc_poly([b]*i+[c2]),cyc_poly([b]*j+[c1]))
    poly=mul(*([trace2]*d['q2_power']+[trace3]*d['q3_power']+[scalar(poly)]))
    leading=add(leading,sc(poly,coefficient))
assert leading==components[6]
stage=pickle.load(open(root/'stageA_Q.pkl','rb'))
leading_tree_representative=add(
    sc(mul(trace2,trace3,stage['a1']),3),
    sc(mul(trace2,trace2,trace2,stage['C0']),-F(1,4)),
    sc(mul(trace3,trace3,stage['C0']),-1))
assert cartan(leading)==cartan(leading_tree_representative)
assert not T.q0(leading_tree_representative)
del stage,leading_tree_representative
for nb in [5,4]:
    rebuilt={}
    for (source_nb,index),coefficient in zip(saved['selected'],saved['coefficients']):
        if source_nb!=nb or not coefficient:continue
        if nb==5:
            d=first['descriptors'][index];poly=from_descriptor(d);assert poly==first['basis'][index]
        else:
            data=pickle.load(open(out/'second_basis'/f'basis_{index:03d}.pkl','rb'))
            poly=from_descriptor(data['descriptor']);assert poly==data['polynomial']
        rebuilt=add(rebuilt,sc(poly,coefficient))
    assert rebuilt==components[nb]
    print('k6 rebuilt trace correction',nb,len(rebuilt),'seconds',time.time()-start,flush=True)

def accumulate(residual,image):
    for w,c in image.items():
        value=residual.get(w,F(0))+c
        if value:residual[w]=value
        elif w in residual:del residual[w]

def chunks(poly,size=3000):
    part={}
    for w,c in poly.items():
        part[w]=c
        if len(part)==size:yield part;part={}
    if part:yield part

residuals={}
for target in [6,5,4]:
    residual={}
    for nb in range(target,7):
        n=nb-target
        for part in chunks(components[nb]):accumulate(residual,T.q0(part) if n==0 else T.qn(n,part))
    assert not residual,(target,len(residual))
    residuals[str(target)]=0
    print('k6 independent full polynomial equation',target,'PASS seconds',time.time()-start,flush=True)
assert all(not Jp(p) and not Jm(p) and all(not graise(p,i) for i in range(2)) for p in components.values())
certificate=dict(coefficient_field='Q',reconstructed_all_nonzero_trace_coefficients=True,
    full_polynomial_residuals=residuals,full_Q0_includes_bare_ghosts=True,
    gauge_and_both_rotation_checks=True,leading_E3_dimension_Q=1,
    leading_Cartan_formula_verified=True,
    leading_tree_class_formula='3 tr(b^2) tr(b^3) a1 - (tr(b^2)^3/4 + tr(b^3)^2) C0',
    leading_tree_class_argument='equal Cartan restrictions and the independently proved injectivity of the complete leading tree module',
    scope='leading k6 scalar class survives through the second-loop equation; no E_infinity or full-lift uniqueness claim',seconds=time.time()-start)
(out/'independent_joint_two_loop_readback.json').write_text(json.dumps(certificate,indent=2)+'\n')
record=json.loads((out/'joint_two_loop_Q_certificate.json').read_text())
record['status']='EXACT_SECOND_LIFT_READ_BACK_LEADING_E3_DIMENSION_ONE'
record['independent_readback']='independent_joint_two_loop_readback.json';record['leading_E3_dimension_Q']=1
(out/'joint_two_loop_Q_certificate.json').write_text(json.dumps(record,indent=2)+'\n')
print('K6 FULL SECOND-LIFT READBACK COMPLETE',flush=True)
