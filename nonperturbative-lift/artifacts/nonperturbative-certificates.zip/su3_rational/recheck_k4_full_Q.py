#!/usr/bin/env python3
"""Independent reconstruction and full-Q readback of the saved SU(3) k4 lift."""
import json
from pathlib import Path
import pickle
import time
from rational_su3 import *
from trace_space_Q import from_descriptor
import fast_wick_edges
fast_wick_edges.install(T)
import fast_selected_direct
fast_selected_direct.install(T)
root=Path(__file__).resolve().parent;out=root/'k4_full';start=time.time()
data=pickle.load(open(out/'C4_Q.pkl','rb'));components=data['components']
expected_leading=pickle.load(open(root/'tower_k4_first_lift_Q.pkl','rb'))['leading']
assert components[4]==expected_leading
a1=pickle.load(open(root/'stageA_Q.pkl','rb'))['a1']
b=('b',0,0);c1=('c',1,0);c2=('c',0,1)
literal_leading=add(mul(cyc_poly([b,b,b]),a1),
    sc(cyc_poly([b,b,c1,b,b,c2]),F(-3,2)),
    sc(mul(cyc_poly([b,b,c1]),cyc_poly([b,b,c2])),F(-3,2)))
assert literal_leading==expected_leading
reconstructed={4:expected_leading,3:{},2:{},1:{},0:{}}
for (nb,i),coefficient in zip(data['selected'],data['coefficients']):
    if not coefficient:continue
    block=pickle.load(open(out/('basis_Nb%d_Nc2.pkl'%nb),'rb'))
    poly=from_descriptor(block['descriptors'][i]);assert poly==block['basis'][i]
    reconstructed[nb]=add(reconstructed[nb],sc(poly,coefficient))
assert reconstructed==components
residuals={}
for target in range(4,-1,-1):
    residual={}
    for nb in range(target,5):
        image=T.q0(components[nb]) if nb==target else T.qn(nb-target,components[nb])
        residual=add(residual,image)
    residuals[str(target)]=len(residual);assert not residual,(target,len(residual))
    print('K4 independent full-Q equation target Nb',target,'PASS seconds',time.time()-start,flush=True)
assert all(not Jp(p) and not Jm(p) for p in components.values())
assert all(not graise(p,i) for p in components.values() for i in range(2))
assert cartan(components[4])
result=dict(coefficient_field='Q',full_Q_residuals_by_target_Nb=residuals,
            full_Q0_includes_undifferentiated_ghosts=True,
            reconstructed_from_original_trace_descriptors=True,gauge_and_both_rotation_checks=True,
            leading_literal_trace_reconstructed=True,
            leading_Cartan_terms=len(cartan(components[4])),
            higher_equations='zero by b-degree',seconds=time.time()-start)
(out/'independent_full_Q_readback.json').write_text(json.dumps(result,indent=2)+'\n')
certificate=json.loads((out/'C4_Q_certificate.json').read_text())
certificate['status']='EXACT_FULL_SCALAR_COCYCLE_AND_LEADING_SURVIVAL_READ_BACK'
certificate['independent_readback']='independent_full_Q_readback.json'
certificate['leading_literal_trace_formula']='tr(b^3) a1 -3/2 tr(b^2 d1c b^2 d2c) -3/2 tr(b^2 d1c)tr(b^2 d2c)'
ambiguity_path=out/'scalar_ambiguity_Q_certificate.json'
if ambiguity_path.exists():
    ambiguity=json.loads(ambiguity_path.read_text())
    if ambiguity.get('saturated'):
        certificate['ambiguity']='unique modulo full Q in the complete rotation-scalar Nb+loop_order=4 block'
        certificate['scalar_block_cohomology_dimension_Q']=ambiguity['cohomology_dimension_Q']
        certificate['scalar_block_certificate']='scalar_ambiguity_Q_certificate.json'
(out/'C4_Q_certificate.json').write_text(json.dumps(certificate,indent=2)+'\n')
print('K4 INDEPENDENT SAVED FULL-Q READBACK COMPLETE',flush=True)
