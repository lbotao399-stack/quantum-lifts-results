#!/usr/bin/env python3
"""Exact product-forest C1 square, with all perturbative closure equations."""
import json
import os
from pathlib import Path
import pickle
import sys
import time
from fractions import Fraction as F

root = Path(__file__).resolve().parent
os.environ['SUN'] = '3'
sys.path.insert(0, str(root.parent / 'rational_c4'))
import exact_product as E
import exact_star as X

A = pickle.load(open(root / 'stageA_Q.pkl', 'rb'))
C0, a1 = A['C0'], A['a1']
assert E.S.N == 3
assert C0 == E.cyc_poly([('c',1,0), ('c',0,1)])
assert a1 == E.sc(E.sub(E.cyc_poly([('b',0,0),('c',1,0),('c',0,1)]),
                        E.cyc_poly([('b',0,0),('c',0,1),('c',1,0)])), F(-1,2))
assert not E.T.q0(a1) and not E.Q1(a1)
components = []
timings = []
for n in range(3):
    start = time.time()
    component = X.star_n(n, a1, a1)
    components.append(component)
    timings.append(time.time() - start)
    pickle.dump(dict(components=components), open(root / 'C1_star_Q_partial.pkl', 'wb'))
    print('loop', n, 'terms', len(component), 'seconds', timings[-1], flush=True)

assert components[0] == pickle.load(open(root / 'C1_square_Q.pkl', 'rb'))['square']
assert components[1] == E.mu1(a1, a1)
print('one-loop independent optimized formula agrees', flush=True)
assert components[2] == E.mu2(a1, a1)
print('two-loop independent optimized formula agrees', flush=True)
residuals = []
for order in range(4):
    terms = [E.T.q0(components[order])] if order < 3 else []
    for n in range(min(order,2)+1):
        r = order-n
        if r and r <= 2-n:
            terms.append(E.T.qn(r, components[n]))
    residual = E.add(*terms)
    residuals.append(len(residual))
    print('closure order', order, 'residual', len(residual), flush=True)
    assert not residual

pickle.dump(dict(components=components, a1=a1), open(root / 'C1_star_Q.pkl', 'wb'))
result = dict(coefficient_field='Q', weight=[4,4], ghost_number=4,
              coefficient_Nb=[2,1,0], terms=[len(p) for p in components],
              timings_seconds=timings, full_Q_closure_residuals=residuals,
              higher_orders='zero: Q_r consumes r b-letters; total b+loop order is 2',
              product_source='exact_star.py product-forest kernel, checked against mu1.py and mu2.py',
              normalization='original engine parameter and a1=-1/2 tr(b d1c d2c-b d2c d1c)',
              leading_class='nonzero, unique H(Q0) class by C1_square_Q_certificate.json',
              incoming_differentials='absent: source Nb=2+r,Nc=3 requires total weight >=7+2r>8',
              E_infinity_class_nonzero=True,
              Cartan_terms=[len(E.cartan(p)) for p in components])
(root / 'C1_star_Q_certificate.json').write_text(json.dumps(result, indent=2)+'\n')
print('C1 STAR C1 EXACT FULL COCYCLE AND NONZERO CLASS: PASS', flush=True)
